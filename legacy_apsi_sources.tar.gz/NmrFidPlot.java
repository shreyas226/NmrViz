import javax.swing.*;
import java.awt.*;

public class NmrFidPlot extends JPanel {
    private double[] fidReal = new double[500];
    private double[] fidImag = new double[500];
    private double phc0_f2 = 0.0;
    private double phc1_f2 = 0.0;

    public NmrFidPlot() {
        setBackground(UIConstants.COLOR_WHITE);
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 1, 0, 0, UIConstants.COLOR_BLUE_BORDER),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
    }

    public void setFidData(double[] real, double[] imag, double phc0, double phc1) {
        if (real != null) this.fidReal = real;
        if (imag != null) this.fidImag = imag;
        this.phc0_f2 = phc0;
        this.phc1_f2 = phc1;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int w = getWidth();
        int h = getHeight();
        
        g2.setColor(UIConstants.COLOR_WHITE);
        g2.fillRect(0, 0, w, h);
        
        int centerY = h / 2;
        g2.setColor(new Color(235, 235, 235));
        g2.drawLine(0, centerY, w, centerY);
        
        g2.setColor(UIConstants.COLOR_CHARCOAL);
        g2.setFont(new Font("Arial", Font.BOLD, 10));
        g2.drawString("1D FID (Time Domain Slice)", 10, 15);
        
        int n = Math.min(fidReal.length, fidImag.length);
        if (n == 0) return;
        
        double[] phasedFid = new double[n];
        double maxVal = 0.0001;
        for (int t = 0; t < n; t++) {
            double theta = Math.toRadians(phc0_f2 + phc1_f2 * (t / (double) Math.max(1, n - 1)));
            phasedFid[t] = fidReal[t] * Math.cos(theta) - fidImag[t] * Math.sin(theta);
            if (Math.abs(phasedFid[t]) > maxVal) {
                maxVal = Math.abs(phasedFid[t]);
            }
        }
        
        g2.setColor(UIConstants.COLOR_PLOT_BLUE);
        g2.setStroke(new BasicStroke(1.2f));
        int prevX = 0;
        int prevY = centerY;
        
        for (int t = 0; t < n; t++) {
            double fracX = t / (double) Math.max(1, n - 1);
            int cx = (int)(fracX * w);
            double val = phasedFid[t];
            int cy = centerY - (int)((val / maxVal) * (h / 2.0 - 20));
            
            if (t > 0) {
                g2.drawLine(prevX, prevY, cx, cy);
            }
            prevX = cx;
            prevY = cy;
        }
    }
}
