import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class UIConstants {
    // 2007-2012 Classic Light Era Styles Constants
    public static final Color COLOR_BG = new Color(240, 243, 246);          // Silver-grey background
    public static final Color COLOR_WHITE = Color.WHITE;
    public static final Color COLOR_CHARCOAL = new Color(40, 40, 40);        // Text color
    public static final Color COLOR_BLUE_BORDER = new Color(160, 181, 205);   // Steel blue borders
    public static final Color COLOR_BLUE_ACCENT = new Color(211, 226, 242);   // Soft light blue header
    public static final Color COLOR_PLOT_BLUE = new Color(30, 96, 145);       // Point markers color (Excel blue)
    public static final Color COLOR_PLOT_HOVER = new Color(230, 57, 70);      // Red highlight on hover
    public static final Color COLOR_GRID_LINE = new Color(225, 225, 225);     // Light grey grid lines
    public static final Color COLOR_TOOLTIP_BG = new Color(255, 255, 204);    // Classic yellow tooltip
    
    public static final Font FONT_SANS = new Font("Arial", Font.PLAIN, 12);
    public static final Font FONT_SANS_BOLD = new Font("Arial", Font.BOLD, 12);
    public static final Font FONT_TITLE = new Font("Arial", Font.BOLD, 14);
    public static final Font FONT_LOG = new Font("Courier New", Font.PLAIN, 12);

    // Border Helper (2007 Light Theme Styled)
    public static Border createRetroBorder(String title) {
        Border line = BorderFactory.createLineBorder(COLOR_BLUE_BORDER);
        return BorderFactory.createTitledBorder(line, " " + title + " ", 
            TitledBorder.LEFT, TitledBorder.TOP, 
            FONT_SANS_BOLD, COLOR_CHARCOAL);
    }
    
    // Button Helper (2007 Light Theme Styled)
    public static JButton createRetroButton(String label) {
        JButton btn = new JButton(label);
        btn.setFont(FONT_SANS_BOLD);
        btn.setBackground(new Color(235, 238, 242));
        btn.setForeground(COLOR_CHARCOAL);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_BLUE_BORDER),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(COLOR_BLUE_ACCENT);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(235, 238, 242));
            }
        });
        return btn;
    }
    
    public static JComboBox<String> createRetroComboBox() {
        JComboBox<String> combo = new JComboBox<>();
        combo.setBackground(COLOR_WHITE);
        combo.setForeground(COLOR_CHARCOAL);
        combo.setFont(FONT_SANS_BOLD);
        combo.setBorder(BorderFactory.createLineBorder(COLOR_BLUE_BORDER));
        combo.setOpaque(true);
        combo.setRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList<?> list, Object val, int idx, boolean isSel, boolean cellHasFocus) {
                JLabel lbl = (JLabel) super.getListCellRendererComponent(list, val, idx, isSel, cellHasFocus);
                lbl.setBackground(isSel ? COLOR_BLUE_ACCENT : COLOR_WHITE);
                lbl.setForeground(COLOR_CHARCOAL);
                lbl.setFont(FONT_SANS_BOLD);
                lbl.setOpaque(true);
                return lbl;
            }
        });
        return combo;
    }
}
