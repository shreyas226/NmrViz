import javax.swing.*;
import java.awt.*;

public class VectorIcon implements Icon {
    private final String type;
    private final int width;
    private final int height;
    
    public VectorIcon(String type, int width, int height) {
        this.type = type;
        this.width = width;
        this.height = height;
    }
    
    public int getIconWidth() { return width; }
    public int getIconHeight() { return height; }
    
    public void paintIcon(Component c, Graphics g, int x, int y) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(c != null ? c.getForeground() : Color.WHITE);
        
        if ("spectrum".equals(type)) {
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawLine(x + 2, y + height - 3, x + width/2, y + 3);
            g2.drawLine(x + width/2, y + 3, x + width - 2, y + height - 3);
        } else if ("phase".equals(type)) {
            g2.setStroke(new BasicStroke(1.5f));
            int prevX = x + 2;
            int prevY = y + height/2;
            for (int i = 1; i <= width - 4; i++) {
                int cx = x + 2 + i;
                int cy = y + height/2 + (int)(Math.sin((i / (double)(width - 4)) * 2 * Math.PI) * 5);
                g2.drawLine(prevX, prevY, cx, cy);
                prevX = cx;
                prevY = cy;
            }
        } else if ("baseline".equals(type)) {
            g2.setStroke(new BasicStroke(1.5f));
            int prevX = x + 2;
            int prevY = y + height - 3;
            for (int i = 1; i <= width - 4; i++) {
                double norm = i / (double)(width - 4);
                int cx = x + 2 + i;
                int cy = y + height - 3 - (int)(Math.sin(norm * Math.PI) * 7);
                g2.drawLine(prevX, prevY, cx, cy);
                prevX = cx;
                prevY = cy;
            }
        } else if ("calib".equals(type)) {
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawLine(x + 2, y + height - 4, x + width/2, y + 3);
            g2.drawLine(x + width/2, y + 3, x + width - 2, y + height - 4);
            g2.drawLine(x + width/2, y + height - 4, x + width/2, y + height - 1);
        } else if ("printer".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRect(x + 2, y + 5, width - 4, height - 10);
            g2.drawLine(x + 4, y + 5, x + 4, y + 2);
            g2.drawLine(x + 4, y + 2, x + width - 4, y + 2);
            g2.drawLine(x + width - 4, y + 2, x + width - 4, y + 5);
            g2.fillRect(x + 4, y + height - 7, width - 8, 3);
        } else if ("export".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRect(x + 2, y + 2, width - 6, height - 5);
            g2.drawLine(x + width - 5, y + 4, x + width - 2, y + 1);
            g2.drawLine(x + width - 4, y + 1, x + width - 2, y + 1);
            g2.drawLine(x + width - 2, y + 3, x + width - 2, y + 1);
        } else if ("copy".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRect(x + 1, y + 4, width - 6, height - 6);
            g2.drawRect(x + 5, y + 1, width - 6, height - 6);
        } else if ("more".equals(type)) {
            g2.fillOval(x + 2, y + height/2 - 1, 3, 3);
            g2.fillOval(x + width/2 - 1, y + height/2 - 1, 3, 3);
            g2.fillOval(x + width - 5, y + height/2 - 1, 3, 3);
        } else if ("layout1".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRect(x + 2, y + 2, width - 4, height - 4);
        } else if ("layout2".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRect(x + 2, y + 2, width - 4, height - 4);
            g2.drawLine(x + width/2, y + 2, x + width/2, y + height - 2);
        } else if ("vzoom".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawLine(x + width/2, y + 2, x + width/2, y + height - 2);
            g2.drawLine(x + width/2, y + 2, x + width/2 - 3, y + 5);
            g2.drawLine(x + width/2, y + 2, x + width/2 + 3, y + 5);
            g2.drawLine(x + width/2, y + height - 2, x + width/2 - 3, y + height - 5);
            g2.drawLine(x + width/2, y + height - 2, x + width/2 + 3, y + height - 5);
        } else if ("hzoom".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawLine(x + 2, y + height/2, x + width - 2, y + height/2);
            g2.drawLine(x + 2, y + height/2, x + 5, y + height/2 - 3);
            g2.drawLine(x + 2, y + height/2, x + 5, y + height/2 + 3);
            g2.drawLine(x + width - 2, y + height/2, x + width - 5, y + height/2 - 3);
            g2.drawLine(x + width - 2, y + height/2, x + width - 5, y + height/2 + 3);
        } else if ("baseline_reset".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawLine(x + 2, y + height - 3, x + width - 2, y + height - 3);
            g2.drawLine(x + width/2, y + 2, x + width/2, y + height - 3);
            g2.drawLine(x + width/2, y + height - 3, x + width/2 - 3, y + height - 6);
            g2.drawLine(x + width/2, y + height - 3, x + width/2 + 3, y + height - 6);
        } else if ("zoomin".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawOval(x + 2, y + 2, 7, 7);
            g2.drawLine(x + 8, y + 8, x + width - 3, y + height - 3);
            g2.drawLine(x + 4, y + 5, x + 7, y + 5);
            g2.drawLine(x + 5, y + 4, x + 5, y + 7);
        } else if ("zoomout".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawOval(x + 2, y + 2, 7, 7);
            g2.drawLine(x + 8, y + 8, x + width - 3, y + height - 3);
            g2.drawLine(x + 4, y + 5, x + 7, y + 5);
        } else if ("undo".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawArc(x + 4, y + 4, 8, 8, 0, 230);
            g2.drawLine(x + 4, y + 8, x + 2, y + 6);
            g2.drawLine(x + 4, y + 8, x + 6, y + 6);
        } else if ("fit".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRect(x + 3, y + 3, width - 6, height - 6);
            g2.fillRect(x + width/2 - 1, y + height/2 - 1, 2, 2);
        } else if ("refresh".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawArc(x + 2, y + 2, width - 4, height - 4, 30, 300);
            g2.drawLine(x + width - 3, y + height/2, x + width - 6, y + height/2 + 3);
            g2.drawLine(x + width - 3, y + height/2, x + width - 1, y + height/2 + 3);
        } else if ("peaks".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawLine(x + 1, y + height - 2, x + width - 1, y + height - 2);
            g2.drawArc(x + 3, y + 2, width - 6, height, 0, 180);
        } else if ("grid".equals(type)) {
            g2.setStroke(new BasicStroke(1.0f));
            g2.drawLine(x + 4, y + 2, x + 4, y + height - 2);
            g2.drawLine(x + width - 4, y + 2, x + width - 4, y + height - 2);
            g2.drawLine(x + 2, y + 4, x + width - 2, y + 4);
            g2.drawLine(x + 2, y + height - 4, x + width - 2, y + height - 4);
        } else if ("hamburger".equals(type)) {
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawLine(x + 2, y + 4, x + width - 2, y + 4);
            g2.drawLine(x + 2, y + height/2, x + width - 2, y + height/2);
            g2.drawLine(x + 2, y + height - 4, x + width - 2, y + height - 4);
        } else if ("pickpeaks".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawLine(x + 1, y + height - 2, x + width - 1, y + height - 2);
            g2.drawArc(x + 3, y + 2, width - 6, height - 4, 0, 180);
            g2.drawLine(x + width/2, y + 2, x + width/2, y + 5);
        } else if ("integrate".equals(type)) {
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawArc(x + width/2 - 2, y + 2, 4, 4, 0, 180);
            g2.drawLine(x + width/2, y + 4, x + width/2, y + height - 4);
            g2.drawArc(x + width/2, y + height - 6, 4, 4, 180, 180);
        } else if ("multiplets".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawLine(x + 3, y + height/2, x + width - 3, y + height/2);
            g2.drawLine(x + width/2, y + 2, x + width/2, y + height/2);
            g2.drawLine(x + 4, y + height/2, x + 4, y + height - 2);
            g2.drawLine(x + width - 4, y + height/2, x + width - 4, y + height - 2);
        } else if ("lineshapes".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawArc(x + 1, y + 4, width/2 - 1, height - 6, 0, 180);
            g2.drawArc(x + width/2 - 1, y + 4, width/2 - 1, height - 6, 0, 180);
        } else if ("quantify".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRect(x + 2, y + 2, width - 4, height - 4);
            g2.drawLine(x + 5, y + height/2, x + width - 5, y + height/2);
        } else if ("sino".equals(type)) {
            g2.setStroke(new BasicStroke(1.2f));
            int prevX = x + 1;
            int prevY = y + height/2;
            for (int i = 1; i < width - 2; i++) {
                int cx = x + 1 + i;
                int cy = y + height/2 + (int)(Math.sin(i * 1.5) * 3) + (i % 2 == 0 ? 2 : -2);
                g2.drawLine(prevX, prevY, cx, cy);
                prevX = cx;
                prevY = cy;
            }
        }
        
        g2.dispose();
    }
}
