import java.util.*;

public class JsonParser {
    public static Map<String, Object> parseObject(String json) {
        Map<String, Object> map = new HashMap<>();
        json = json.trim();
        if (json.startsWith("{") && json.endsWith("}")) {
            json = json.substring(1, json.length() - 1).trim();
        }
        
        int i = 0;
        while (i < json.length()) {
            while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
            if (i >= json.length()) break;
            if (json.charAt(i) != '"') break;
            
            int keyStart = i + 1;
            i++;
            while (i < json.length() && json.charAt(i) != '"') i++;
            String key = json.substring(keyStart, i);
            i++; // skip quote
            
            while (i < json.length() && json.charAt(i) != ':') i++;
            i++; // skip colon
            while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
            
            if (i >= json.length()) break;
            Object value = null;
            
            if (json.charAt(i) == '"') {
                int valStart = i + 1;
                i++;
                while (i < json.length() && json.charAt(i) != '"') i++;
                value = json.substring(valStart, i);
                i++;
            } else if (json.charAt(i) == '[') {
                int bracketCount = 1;
                int startList = i;
                i++;
                while (i < json.length() && bracketCount > 0) {
                    if (json.charAt(i) == '[') bracketCount++;
                    else if (json.charAt(i) == ']') bracketCount--;
                    i++;
                }
                value = json.substring(startList, i);
            } else if (json.charAt(i) == '{') {
                int braceCount = 1;
                int startObj = i;
                i++;
                while (i < json.length() && braceCount > 0) {
                    if (json.charAt(i) == '{') braceCount++;
                    else if (json.charAt(i) == '}') braceCount--;
                    i++;
                }
                value = json.substring(startObj, i);
            } else {
                int startVal = i;
                while (i < json.length() && json.charAt(i) != ',' && json.charAt(i) != '}') {
                    i++;
                }
                String valStr = json.substring(startVal, i).trim();
                if (valStr.equals("null")) value = null;
                else if (valStr.equals("true")) value = true;
                else if (valStr.equals("false")) value = false;
                else {
                    try {
                        value = Double.parseDouble(valStr);
                    } catch (NumberFormatException ex) {
                        value = valStr;
                    }
                }
            }
            
            map.put(key, value);
            while (i < json.length() && json.charAt(i) != ',') i++;
            i++;
        }
        return map;
    }
    
    public static List<Map<String, Object>> parseList(String listStr) {
        List<Map<String, Object>> list = new ArrayList<>();
        listStr = listStr.trim();
        if (listStr.startsWith("[") && listStr.endsWith("]")) {
            listStr = listStr.substring(1, listStr.length() - 1).trim();
        }
        
        int i = 0;
        while (i < listStr.length()) {
            while (i < listStr.length() && Character.isWhitespace(listStr.charAt(i))) i++;
            if (i >= listStr.length()) break;
            
            if (listStr.charAt(i) == '{') {
                int braceCount = 1;
                int startObj = i;
                i++;
                while (i < listStr.length() && braceCount > 0) {
                    if (listStr.charAt(i) == '{') braceCount++;
                    else if (listStr.charAt(i) == '}') braceCount--;
                    i++;
                }
                String objStr = listStr.substring(startObj, i);
                list.add(parseObject(objStr));
            } else {
                i++;
            }
            while (i < listStr.length() && listStr.charAt(i) != ',') i++;
            i++;
        }
        return list;
    }
    
    public static List<String> parseStringList(String listStr) {
        List<String> list = new ArrayList<>();
        listStr = listStr.trim();
        if (listStr.startsWith("[") && listStr.endsWith("]")) {
            listStr = listStr.substring(1, listStr.length() - 1).trim();
        }
        
        int i = 0;
        while (i < listStr.length()) {
            while (i < listStr.length() && Character.isWhitespace(listStr.charAt(i))) i++;
            if (i >= listStr.length()) break;
            
            if (listStr.charAt(i) == '"') {
                int startVal = i + 1;
                i++;
                while (i < listStr.length() && listStr.charAt(i) != '"') i++;
                list.add(listStr.substring(startVal, i));
                i++;
            } else {
                i++;
            }
            while (i < listStr.length() && listStr.charAt(i) != ',') i++;
            i++;
        }
        return list;
    }
}
