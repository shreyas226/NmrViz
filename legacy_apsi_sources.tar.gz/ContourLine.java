import java.awt.geom.Point2D;
import java.util.List;

public class ContourLine {
    public double level;
    public boolean isPositive;
    public List<List<Point2D.Double>> segments;
    
    public ContourLine(double level, boolean isPositive, List<List<Point2D.Double>> segments) {
        this.level = level;
        this.isPositive = isPositive;
        this.segments = segments;
    }
}
