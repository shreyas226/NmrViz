public class DataPoint {
    public String seqId;
    public String residue;
    public double x;
    public double y;
    public Double z;
    
    public DataPoint(String seqId, String residue, double x, double y, Double z) {
        this.seqId = seqId;
        this.residue = residue;
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
