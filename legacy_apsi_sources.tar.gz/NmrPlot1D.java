import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

/**
 * 1D spectrum panel.
 *
 * The 2D panel draws contour polylines over a ppm/ppm plane; this one draws a
 * single intensity-vs-ppm trace, but keeps the same public surface
 * (setData/resetView/zoomIn/zoomOut/zoomX/zoomY/setShowGrid/setShowLabels) so
 * the existing toolbar and keyboard shortcuts drive it without special cases.
 *
 * The trace arrives from the Python backend already decimated to a min/max
 * envelope, so a 128k-point spectrum is a few thousand screen-ready vertices.
 */
public class NmrPlot1D extends JPanel {
    private List<Point2D.Double> trace = new ArrayList<>();
    private List<DataPoint> peaks = new ArrayList<>();
    private String xLabel = "1H";

    private boolean invertX = true;      // ppm runs high -> low, left -> right
    private boolean showGrid = true;
    private boolean showLabels = true;

    private Point dragStart = null;
    private DataPoint hoveredPeak = null;
    private Point hoveredScreenPos = null;

    private String expTitle = "";
    private String expInfoText = "";

    private double dataMinX, dataMaxX, dataMinY, dataMaxY;
    private double viewMinX, viewMaxX, viewMinY, viewMaxY;
    private final int margin = 60;
    // Intensity values are long numbers, so the left gutter needs more room
    // than the square 2D plot's uniform margin.
    private final int leftMargin = 86;

    public NmrPlot1D() {
        setBackground(UIConstants.COLOR_WHITE);

        MouseAdapter mouseAdapter = new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                dragStart = e.getPoint();
            }
            public void mouseReleased(MouseEvent e) {
                dragStart = null;
            }
            public void mouseDragged(MouseEvent e) {
                if (dragStart == null || trace.isEmpty()) return;
                int dx = e.getX() - dragStart.x;
                int dy = e.getY() - dragStart.y;

                int plotWidth = getWidth() - leftMargin - margin;
                int plotHeight = getHeight() - 2 * margin;
                if (plotWidth <= 0 || plotHeight <= 0) return;

                double shiftX = dx * (viewMaxX - viewMinX) / plotWidth;
                double shiftY = dy * (viewMaxY - viewMinY) / plotHeight;

                if (invertX) {
                    viewMinX += shiftX; viewMaxX += shiftX;
                } else {
                    viewMinX -= shiftX; viewMaxX -= shiftX;
                }
                // Intensity always increases upward, so dragging down moves
                // the view up the intensity axis.
                viewMinY += shiftY; viewMaxY += shiftY;

                dragStart = e.getPoint();
                repaint();
            }
            public void mouseWheelMoved(MouseWheelEvent e) {
                if (trace.isEmpty()) return;
                double rotation = e.getPreciseWheelRotation();
                double scaleFactor = 1.0 + rotation * 0.03;
                if (scaleFactor < 0.8) scaleFactor = 0.8;
                if (scaleFactor > 1.25) scaleFactor = 1.25;

                // Zoom the ppm axis about the cursor, which is what you want
                // when homing in on a multiplet.
                int plotWidth = getWidth() - leftMargin - margin;
                double frac = plotWidth > 0
                        ? Math.max(0.0, Math.min(1.0, (e.getX() - leftMargin) / (double) plotWidth))
                        : 0.5;
                if (invertX) frac = 1.0 - frac;
                double anchor = viewMinX + frac * (viewMaxX - viewMinX);
                viewMinX = anchor - (anchor - viewMinX) * scaleFactor;
                viewMaxX = anchor + (viewMaxX - anchor) * scaleFactor;
                repaint();
            }
            public void mouseMoved(MouseEvent e) {
                checkHover(e.getPoint());
            }
        };
        addMouseListener(mouseAdapter);
        addMouseMotionListener(mouseAdapter);
        addMouseWheelListener(mouseAdapter);
    }

    public void setData(List<Point2D.Double> tracePoints, List<DataPoint> peakList,
                        String xl, boolean ix) {
        this.trace = tracePoints != null ? tracePoints : new ArrayList<>();
        this.peaks = peakList != null ? peakList : new ArrayList<>();
        this.xLabel = xl != null ? xl : "1H";
        this.invertX = ix;
        calculateRanges();
        resetView();
    }

    public void setMetadata(String title, String info) {
        this.expTitle = title != null ? title : "";
        this.expInfoText = info != null ? info : "";
        repaint();
    }

    public int getTraceSize() { return trace.size(); }

    private void calculateRanges() {
        if (trace.isEmpty()) return;
        dataMinX = Double.MAX_VALUE; dataMaxX = -Double.MAX_VALUE;
        dataMinY = Double.MAX_VALUE; dataMaxY = -Double.MAX_VALUE;

        for (Point2D.Double p : trace) {
            if (p.x < dataMinX) dataMinX = p.x;
            if (p.x > dataMaxX) dataMaxX = p.x;
            if (p.y < dataMinY) dataMinY = p.y;
            if (p.y > dataMaxY) dataMaxY = p.y;
        }

        double padX = (dataMaxX - dataMinX) * 0.02; if (padX == 0) padX = 1.0;
        dataMinX -= padX; dataMaxX += padX;

        // Headroom above the tallest peak, and a little room below the
        // baseline so negative excursions are not clipped off.
        double span = dataMaxY - dataMinY; if (span == 0) span = 1.0;
        dataMaxY += span * 0.08;
        dataMinY -= span * 0.04;
    }

    public void resetView() {
        viewMinX = dataMinX; viewMaxX = dataMaxX;
        viewMinY = dataMinY; viewMaxY = dataMaxY;
        repaint();
    }

    public void zoomIn()  { zoomX(0.8);  zoomY(0.8); }
    public void zoomOut() { zoomX(1.25); zoomY(1.25); }

    public void zoomX(double scaleFactor) {
        double cx = (viewMinX + viewMaxX) / 2.0;
        double rx = viewMaxX - viewMinX;
        viewMinX = cx - rx * scaleFactor / 2.0;
        viewMaxX = cx + rx * scaleFactor / 2.0;
        repaint();
    }

    /**
     * Scale the intensity axis about the baseline rather than the middle of
     * the view -- that is how a spectrometer's intensity control behaves, and
     * it keeps the baseline pinned while peaks grow or shrink.
     */
    public void zoomY(double scaleFactor) {
        viewMinY *= scaleFactor;
        viewMaxY *= scaleFactor;
        repaint();
    }

    public void setShowGrid(boolean show) { this.showGrid = show; repaint(); }
    public void setShowLabels(boolean show) { this.showLabels = show; repaint(); }

    private int screenX(double ppm, int plotWidth) {
        double nx = (ppm - viewMinX) / (viewMaxX - viewMinX);
        if (invertX) nx = 1.0 - nx;
        return leftMargin + (int) (nx * plotWidth);
    }

    private int screenY(double intensity, int plotHeight) {
        double ny = (intensity - viewMinY) / (viewMaxY - viewMinY);
        // Clamp well outside the panel instead of letting a hugely zoomed
        // value overflow the int cast and wrap to the other side.
        double py = margin + (1.0 - ny) * plotHeight;
        if (py < -1e6) py = -1e6;
        if (py > 1e6) py = 1e6;
        return (int) py;
    }

    private void checkHover(Point mousePos) {
        if (peaks.isEmpty()) return;
        int plotWidth = getWidth() - leftMargin - margin;
        int plotHeight = getHeight() - 2 * margin;
        if (plotWidth <= 0 || plotHeight <= 0) return;

        DataPoint closest = null;
        Point closestPos = null;
        double minDist = 10.0;

        for (DataPoint p : peaks) {
            int px = screenX(p.x, plotWidth);
            int py = screenY(p.y, plotHeight);
            double dist = mousePos.distance(px, py);
            if (dist < minDist) {
                minDist = dist;
                closest = p;
                closestPos = new Point(px, py);
            }
        }

        if (hoveredPeak != closest) {
            hoveredPeak = closest;
            hoveredScreenPos = closestPos;
            repaint();
        }
    }

    private static String formatIntensity(double v) {
        double abs = Math.abs(v);
        if (abs >= 1e6 || (abs > 0 && abs < 1e-2)) return String.format("%.1e", v);
        if (abs >= 1e3) return String.format("%.0f", v);
        return String.format("%.1f", v);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        g2.setColor(UIConstants.COLOR_WHITE);
        g2.fillRect(0, 0, width, height);

        int plotWidth = width - leftMargin - margin;
        int plotHeight = height - 2 * margin;

        g2.setColor(UIConstants.COLOR_BLUE_BORDER);
        g2.drawRect(leftMargin, margin, plotWidth, plotHeight);

        if (trace.isEmpty()) {
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            g2.setFont(UIConstants.FONT_SANS);
            g2.drawString("NO DATA LOADED", width / 2 - 50, height / 2);
            return;
        }

        // Experiment metadata, same placement as the 2D panel
        if (!expInfoText.isEmpty() || !expTitle.isEmpty()) {
            g2.setFont(new Font("Arial", Font.BOLD, 12));
            if (!expInfoText.isEmpty()) {
                g2.setColor(new Color(80, 80, 80));
                g2.drawString(expInfoText, leftMargin + 15, margin + 25);
            }
            if (!expTitle.isEmpty()) {
                g2.setColor(new Color(210, 20, 20));
                g2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
                g2.drawString(expTitle, leftMargin + 15, margin + 45);
            }
        }

        // Grid and tick labels
        g2.setFont(UIConstants.FONT_SANS);
        for (int k = 0; k <= 10; k++) {
            double frac = k / 10.0;

            int gx = leftMargin + (int) (frac * plotWidth);
            if (showGrid) {
                g2.setColor(UIConstants.COLOR_GRID_LINE);
                g2.drawLine(gx, margin, gx, margin + plotHeight);
            }
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            double vx = viewMinX + (invertX ? (1.0 - frac) : frac) * (viewMaxX - viewMinX);
            g2.drawString(String.format("%.2f", vx), gx - 15, margin + plotHeight + 15);

            int gy = margin + (int) (frac * plotHeight);
            if (showGrid) {
                g2.setColor(UIConstants.COLOR_GRID_LINE);
                g2.drawLine(leftMargin, gy, leftMargin + plotWidth, gy);
            }
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            double vy = viewMinY + (1.0 - frac) * (viewMaxY - viewMinY);
            String vyText = formatIntensity(vy);
            int vyWidth = g2.getFontMetrics().stringWidth(vyText);
            g2.drawString(vyText, leftMargin - 8 - vyWidth, gy + 5);
        }

        // Axis labels
        g2.setColor(UIConstants.COLOR_CHARCOAL);
        g2.setFont(UIConstants.FONT_SANS_BOLD);
        g2.drawString(xLabel + " (PPM)", width / 2 - 20, margin + plotHeight + 40);

        g2.translate(16, height / 2 + 30);
        g2.rotate(-Math.PI / 2);
        g2.drawString("Intensity", 0, 0);
        g2.rotate(Math.PI / 2);
        g2.translate(-16, -(height / 2 + 30));

        Shape oldClip = g2.getClip();
        g2.setClip(leftMargin + 1, margin + 1, plotWidth - 1, plotHeight - 1);

        // Baseline
        int zeroY = screenY(0.0, plotHeight);
        if (zeroY >= margin && zeroY <= margin + plotHeight) {
            g2.setColor(new Color(200, 200, 200));
            g2.drawLine(leftMargin, zeroY, leftMargin + plotWidth, zeroY);
        }

        // The trace itself. Only the vertices inside the current ppm window
        // are emitted, so zooming in costs less work rather than more.
        int[] xs = new int[trace.size()];
        int[] ys = new int[trace.size()];
        int n = 0;
        double lo = Math.min(viewMinX, viewMaxX);
        double hi = Math.max(viewMinX, viewMaxX);
        for (int i = 0; i < trace.size(); i++) {
            Point2D.Double p = trace.get(i);
            // Keep one vertex either side of the window so the line does not
            // stop short at the panel edge.
            boolean inside = p.x >= lo && p.x <= hi;
            boolean neighbourInside =
                    (i > 0 && trace.get(i - 1).x >= lo && trace.get(i - 1).x <= hi) ||
                    (i + 1 < trace.size() && trace.get(i + 1).x >= lo && trace.get(i + 1).x <= hi);
            if (!inside && !neighbourInside) continue;
            xs[n] = screenX(p.x, plotWidth);
            ys[n] = screenY(p.y, plotHeight);
            n++;
        }
        if (n >= 2) {
            g2.setColor(UIConstants.COLOR_PLOT_BLUE);
            g2.setStroke(new BasicStroke(1.0f));
            g2.drawPolyline(xs, ys, n);
        }

        // Picked peaks. The list arrives ranked by intensity, so labelling
        // greedily and skipping anything too close to an already-placed label
        // keeps the strongest peaks legible instead of letting a crowded
        // multiplet turn into a smear of overlapping numbers.
        List<Integer> labelledAt = new ArrayList<>();
        g2.setFont(new Font("Arial", Font.PLAIN, 9));
        for (DataPoint p : peaks) {
            if (p.x < lo || p.x > hi) continue;
            int px = screenX(p.x, plotWidth);
            int py = screenY(p.y, plotHeight);

            g2.setColor(UIConstants.COLOR_PLOT_HOVER);
            g2.drawLine(px, py - 10, px, py - 3);

            if (!showLabels) continue;
            boolean crowded = false;
            for (int placed : labelledAt) {
                if (Math.abs(placed - px) < 28) { crowded = true; break; }
            }
            if (crowded) continue;
            labelledAt.add(px);

            g2.setColor(UIConstants.COLOR_CHARCOAL);
            g2.drawString(String.format("%.2f", p.x), px - 10, py - 13);
        }

        g2.setClip(oldClip);

        // Hover tooltip
        if (hoveredPeak != null && hoveredScreenPos != null) {
            g2.setColor(UIConstants.COLOR_PLOT_HOVER);
            g2.fillOval(hoveredScreenPos.x - 4, hoveredScreenPos.y - 4, 8, 8);
            g2.setColor(Color.BLACK);
            g2.drawOval(hoveredScreenPos.x - 4, hoveredScreenPos.y - 4, 8, 8);

            String text1 = "Peak: " + hoveredPeak.seqId;
            String text2 = xLabel + ": " + String.format("%.4f ppm", hoveredPeak.x);
            String text3 = "Intensity: " + formatIntensity(hoveredPeak.y);

            int tx = hoveredScreenPos.x + 10;
            int ty = hoveredScreenPos.y - 60;
            int boxWidth = 190;
            int boxHeight = 52;
            if (tx + boxWidth > getWidth()) tx = hoveredScreenPos.x - boxWidth - 10;
            if (ty < 0) ty = hoveredScreenPos.y + 10;

            g2.setColor(UIConstants.COLOR_TOOLTIP_BG);
            g2.fillRect(tx, ty, boxWidth, boxHeight);
            g2.setColor(new Color(100, 100, 100));
            g2.drawRect(tx, ty, boxWidth, boxHeight);

            g2.setColor(UIConstants.COLOR_CHARCOAL);
            g2.setFont(UIConstants.FONT_SANS);
            g2.drawString(text1, tx + 8, ty + 16);
            g2.drawString(text2, tx + 8, ty + 31);
            g2.drawString(text3, tx + 8, ty + 46);
        }
    }
}
