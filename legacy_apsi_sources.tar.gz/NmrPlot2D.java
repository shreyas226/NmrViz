import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.util.*;
import java.util.List;

public class NmrPlot2D extends JPanel {
    private List<DataPoint> points = new ArrayList<>();
    private List<ContourLine> contourLines = new ArrayList<>();
    private String xLabel = "X";
    private String yLabel = "Y";
    private String zLabel = "Z";
    private boolean invertX = true;
    private boolean invertY = true;
    private boolean showGrid = true;
    private boolean showLabels = true;
    
    // Panning anchor
    private Point dragStart = null;
    
    // Hover
    private DataPoint hoveredPoint = null;
    private Point hoveredScreenPos = null;
    
    // Experiment metadata
    private String expTitle = "";
    private String expInfoText = "";
    
    // Data Ranges (constant original ranges)
    private double dataMinX, dataMaxX, dataMinY, dataMaxY;
    
    // Current Viewport Ranges (update on zoom & pan)
    private double viewMinX, viewMaxX, viewMinY, viewMaxY;
    private final int margin = 60;

    public NmrPlot2D() {
        setBackground(UIConstants.COLOR_WHITE);
        
        MouseAdapter mouseAdapter = new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                dragStart = e.getPoint();
            }
            public void mouseReleased(MouseEvent e) {
                dragStart = null;
            }
            public void mouseDragged(MouseEvent e) {
                if (dragStart != null && !points.isEmpty()) {
                    int dx = e.getX() - dragStart.x;
                    int dy = e.getY() - dragStart.y;
                    
                    int plotWidth = getWidth() - 2 * margin;
                    int plotHeight = getHeight() - 2 * margin;
                    if (plotWidth <= 0 || plotHeight <= 0) return;
                    
                    double factorX = (viewMaxX - viewMinX) / plotWidth;
                    double factorY = (viewMaxY - viewMinY) / plotHeight;
                    
                    double shiftX = dx * factorX;
                    double shiftY = dy * factorY;
                    
                    if (invertX) {
                        viewMinX += shiftX;
                        viewMaxX += shiftX;
                    } else {
                        viewMinX -= shiftX;
                        viewMaxX -= shiftX;
                    }
                    
                    if (invertY) {
                        viewMinY += shiftY;
                        viewMaxY += shiftY;
                    } else {
                        viewMinY -= shiftY;
                        viewMaxY -= shiftY;
                    }
                    
                    dragStart = e.getPoint();
                    repaint();
                }
            }
            public void mouseWheelMoved(MouseWheelEvent e) {
                if (points.isEmpty()) return;
                
                // Smooth zooming proportional to precise scroll wheel rotation
                double rotation = e.getPreciseWheelRotation();
                double scaleFactor = 1.0 + rotation * 0.03; // Gentle 3% zoom per tick
                
                // Bound the zoom factor per tick for stability
                if (scaleFactor < 0.8) scaleFactor = 0.8;
                if (scaleFactor > 1.25) scaleFactor = 1.25;
                
                double cx = (viewMinX + viewMaxX) / 2.0;
                double rx = viewMaxX - viewMinX;
                viewMinX = cx - rx * scaleFactor / 2.0;
                viewMaxX = cx + rx * scaleFactor / 2.0;
                
                double cy = (viewMinY + viewMaxY) / 2.0;
                double ry = viewMaxY - viewMinY;
                viewMinY = cy - ry * scaleFactor / 2.0;
                viewMaxY = cy + ry * scaleFactor / 2.0;
                
                repaint();
            }
            public void mouseMoved(MouseEvent e) {
                checkHover(e.getPoint());
            }
        };
        addMouseListener(mouseAdapter);
        addMouseMotionListener(mouseAdapter);
        addMouseWheelListener(mouseAdapter);
    }

    public void setData(List<DataPoint> pts, List<ContourLine> contours, String xl, String yl, String zl, boolean ix, boolean iy) {
        this.points = pts;
        this.contourLines = contours;
        this.xLabel = xl;
        this.yLabel = yl;
        this.zLabel = zl;
        this.invertX = ix;
        this.invertY = iy;
        
        calculateRanges();
        resetView();
    }
    
    public void setMetadata(String title, String info) {
        this.expTitle = title != null ? title : "";
        this.expInfoText = info != null ? info : "";
        repaint();
    }
    
    private void calculateRanges() {
        if (points.isEmpty()) return;
        dataMinX = Double.MAX_VALUE; dataMaxX = -Double.MAX_VALUE;
        dataMinY = Double.MAX_VALUE; dataMaxY = -Double.MAX_VALUE;
        
        for (DataPoint p : points) {
            if (p.x < dataMinX) dataMinX = p.x;
            if (p.x > dataMaxX) dataMaxX = p.x;
            if (p.y < dataMinY) dataMinY = p.y;
            if (p.y > dataMaxY) dataMaxY = p.y;
        }
        
        // Add padding
        double padX = (dataMaxX - dataMinX) * 0.1; if (padX == 0) padX = 1.0;
        dataMinX -= padX; dataMaxX += padX;
        double padY = (dataMaxY - dataMinY) * 0.1; if (padY == 0) padY = 1.0;
        dataMinY -= padY; dataMaxY += padY;
    }
    
    public void resetView() {
        viewMinX = dataMinX;
        viewMaxX = dataMaxX;
        viewMinY = dataMinY;
        viewMaxY = dataMaxY;
        repaint();
    }
    
    public void zoomIn() {
        double cx = (viewMinX + viewMaxX) / 2.0;
        double rx = viewMaxX - viewMinX;
        viewMinX = cx - rx * 0.8 / 2.0;
        viewMaxX = cx + rx * 0.8 / 2.0;
        
        double cy = (viewMinY + viewMaxY) / 2.0;
        double ry = viewMaxY - viewMinY;
        viewMinY = cy - ry * 0.8 / 2.0;
        viewMaxY = cy + ry * 0.8 / 2.0;
        repaint();
    }
    
    public void zoomOut() {
        double cx = (viewMinX + viewMaxX) / 2.0;
        double rx = viewMaxX - viewMinX;
        viewMinX = cx - rx * 1.25 / 2.0;
        viewMaxX = cx + rx * 1.25 / 2.0;
        
        double cy = (viewMinY + viewMaxY) / 2.0;
        double ry = viewMaxY - viewMinY;
        viewMinY = cy - ry * 1.25 / 2.0;
        viewMaxY = cy + ry * 1.25 / 2.0;
        repaint();
    }
    
    public void setShowGrid(boolean show) { this.showGrid = show; repaint(); }
    public void setShowLabels(boolean show) { this.showLabels = show; repaint(); }
    
    public void zoomX(double scaleFactor) {
        double cx = (viewMinX + viewMaxX) / 2.0;
        double rx = viewMaxX - viewMinX;
        viewMinX = cx - rx * scaleFactor / 2.0;
        viewMaxX = cx + rx * scaleFactor / 2.0;
        repaint();
    }
    
    public void zoomY(double scaleFactor) {
        double cy = (viewMinY + viewMaxY) / 2.0;
        double ry = viewMaxY - viewMinY;
        viewMinY = cy - ry * scaleFactor / 2.0;
        viewMaxY = cy + ry * scaleFactor / 2.0;
        repaint();
    }
    
    private void checkHover(Point mousePos) {
        if (points.isEmpty()) return;
        DataPoint closest = null;
        double minDist = 8.0; 
        Point closestPos = null;
        
        int width = getWidth();
        int height = getHeight();
        int plotWidth = width - 2 * margin;
        int plotHeight = height - 2 * margin;
        if (plotWidth <= 0 || plotHeight <= 0) return;
        
        for (DataPoint p : points) {
            double nx = (p.x - viewMinX) / (viewMaxX - viewMinX);
            if (invertX) nx = 1.0 - nx;
            double ny = (p.y - viewMinY) / (viewMaxY - viewMinY);
            if (invertY) ny = 1.0 - ny;
            
            int px = margin + (int)(nx * plotWidth);
            int py = margin + (int)(ny * plotHeight);
            
            double dist = mousePos.distance(px, py);
            if (dist < minDist) {
                minDist = dist;
                closest = p;
                closestPos = new Point(px, py);
            }
        }
        
        if (hoveredPoint != closest) {
            hoveredPoint = closest;
            hoveredScreenPos = closestPos;
            repaint();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        g2.setColor(UIConstants.COLOR_WHITE);
        g2.fillRect(0, 0, width, height);
        
        int plotWidth = width - 2 * margin;
        int plotHeight = height - 2 * margin;
        
        g2.setColor(UIConstants.COLOR_BLUE_BORDER);
        g2.drawRect(margin, margin, plotWidth, plotHeight);
        
        if (points.isEmpty()) {
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            g2.setFont(UIConstants.FONT_SANS);
            g2.drawString("NO DATA LOADED", width / 2 - 50, height / 2);
            return;
        }

        // Draw experiment metadata inside the plot (like TopSpin does)
        if (!expInfoText.isEmpty() || !expTitle.isEmpty()) {
            g2.setFont(new Font("Arial", Font.BOLD, 12));
            if (!expInfoText.isEmpty()) {
                g2.setColor(new Color(80, 80, 80));
                g2.drawString(expInfoText, margin + 15, margin + 25);
            }
            if (!expTitle.isEmpty()) {
                g2.setColor(new Color(210, 20, 20)); // Bold Red
                g2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
                g2.drawString(expTitle, margin + 15, margin + 45);
            }
        }
        
        // Draw Grid Lines (ticks map to view bounds)
        g2.setFont(UIConstants.FONT_SANS);
        for (int k = 0; k <= 10; k++) {
            double frac = k / 10.0;
            int gx = margin + (int)(frac * plotWidth);
            if (showGrid) {
                g2.setColor(UIConstants.COLOR_GRID_LINE);
                g2.drawLine(gx, margin, gx, margin + plotHeight);
            }
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            double vx = viewMinX + (invertX ? (1.0 - frac) : frac) * (viewMaxX - viewMinX);
            g2.drawString(String.format("%.2f", vx), gx - 15, margin + plotHeight + 15);
            
            int gy = margin + (int)(frac * plotHeight);
            if (showGrid) {
                g2.setColor(UIConstants.COLOR_GRID_LINE);
                g2.drawLine(margin, gy, margin + plotWidth, gy);
            }
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            double vy = viewMinY + (invertY ? (1.0 - frac) : frac) * (viewMaxY - viewMinY);
            g2.drawString(String.format("%.2f", vy), margin - 45, gy + 5);
        }
        
        // Axes Labels
        g2.setColor(UIConstants.COLOR_CHARCOAL);
        g2.setFont(UIConstants.FONT_SANS_BOLD);
        g2.drawString(xLabel + " (PPM)", width / 2 - 20, margin + plotHeight + 40);
        
        g2.translate(20, height / 2 + 30);
        g2.rotate(-Math.PI / 2);
        g2.drawString(yLabel + " (PPM)", 0, 0);
        g2.rotate(Math.PI / 2);
        g2.translate(-20, -(height / 2 + 30));
        
        // Draw contour lines
        for (ContourLine cl : contourLines) {
            if (cl.isPositive) {
                g2.setColor(new Color(30, 96, 145, 120)); // Blue positive contours
            } else {
                g2.setColor(new Color(230, 57, 70, 100)); // Red negative contours
            }
            g2.setStroke(new BasicStroke(1.0f));
            
            for (List<Point2D.Double> segment : cl.segments) {
                if (segment.size() < 2) continue;
                
                int[] xPoints = new int[segment.size()];
                int[] yPoints = new int[segment.size()];
                int nPoints = 0;
                
                for (Point2D.Double pt : segment) {
                    double nx = (pt.x - viewMinX) / (viewMaxX - viewMinX);
                    if (invertX) nx = 1.0 - nx;
                    double ny = (pt.y - viewMinY) / (viewMaxY - viewMinY);
                    if (invertY) ny = 1.0 - ny;
                    
                    int px = margin + (int)(nx * plotWidth);
                    int py = margin + (int)(ny * plotHeight);
                    
                    xPoints[nPoints] = px;
                    yPoints[nPoints] = py;
                    nPoints++;
                }
                
                g2.drawPolyline(xPoints, yPoints, nPoints);
            }
        }

        // Render points inside viewport bounds
        for (DataPoint p : points) {
            double nx = (p.x - viewMinX) / (viewMaxX - viewMinX);
            if (invertX) nx = 1.0 - nx;
            double ny = (p.y - viewMinY) / (viewMaxY - viewMinY);
            if (invertY) ny = 1.0 - ny;
            
            int px = margin + (int)(nx * plotWidth);
            int py = margin + (int)(ny * plotHeight);
            
            if (px >= margin && px <= margin + plotWidth && py >= margin && py <= margin + plotHeight) {
                g2.setColor(UIConstants.COLOR_PLOT_BLUE);
                g2.fillOval(px - 3, py - 3, 6, 6);
                g2.setColor(new Color(15, 50, 75));
                g2.drawOval(px - 3, py - 3, 6, 6);
                
                if (showLabels) {
                    g2.setFont(new Font("Arial", Font.PLAIN, 9));
                    g2.setColor(UIConstants.COLOR_CHARCOAL);
                    g2.drawString(p.residue + " (" + String.format("%.2f", p.x) + ")", px + 5, py - 2);
                }
            }
        }
        
        // Render hover tooltip showing 3 parameters & elements
        if (hoveredPoint != null && hoveredScreenPos != null) {
            g2.setColor(UIConstants.COLOR_PLOT_HOVER); // red highlight
            g2.fillOval(hoveredScreenPos.x - 4, hoveredScreenPos.y - 4, 8, 8);
            g2.setColor(Color.BLACK);
            g2.drawOval(hoveredScreenPos.x - 4, hoveredScreenPos.y - 4, 8, 8);
            
            String text1 = "Residue: " + hoveredPoint.seqId + " " + hoveredPoint.residue;
            String text2 = NmrVisualizer.getAtomDisplayName(xLabel, hoveredPoint.residue) + ": " + String.format("%.3f ppm", hoveredPoint.x);
            String text3 = NmrVisualizer.getAtomDisplayName(yLabel, hoveredPoint.residue) + ": " + String.format("%.3f ppm", hoveredPoint.y);
            
            // Read the Z shift parameter if it's available
            String text4 = "";
            if (hoveredPoint.z != null) {
                text4 = NmrVisualizer.getAtomDisplayName(zLabel, hoveredPoint.residue) + ": " + String.format("%.3f ppm", hoveredPoint.z);
            }
            
            int tx = hoveredScreenPos.x + 10;
            int ty = hoveredScreenPos.y - 65; 
            int boxHeight = 50;
            if (!text4.isEmpty()) {
                boxHeight = 65;
                ty = hoveredScreenPos.y - 80;
            }
            
            // Classic Windows yellow tooltip
            g2.setColor(UIConstants.COLOR_TOOLTIP_BG);
            g2.fillRect(tx, ty, 220, boxHeight); 
            g2.setColor(new Color(100, 100, 100)); // gray tooltip border
            g2.drawRect(tx, ty, 220, boxHeight);
            
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            g2.setFont(UIConstants.FONT_SANS);
            g2.drawString(text1, tx + 8, ty + 15);
            g2.drawString(text2, tx + 8, ty + 30);
            g2.drawString(text3, tx + 8, ty + 45);
            if (!text4.isEmpty()) {
                g2.drawString(text4, tx + 8, ty + 60);
            }
        }
    }
}
