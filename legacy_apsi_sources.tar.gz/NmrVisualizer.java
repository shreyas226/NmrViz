import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;
import java.net.URI;
import java.net.http.*;
import java.util.concurrent.CompletableFuture;
import java.awt.geom.Point2D;

public class NmrVisualizer extends JFrame {
    // 2007-2012 Classic Light Era Styles Constants
    private static final Color COLOR_BG = new Color(240, 243, 246);          // Silver-grey background
    private static final Color COLOR_WHITE = Color.WHITE;
    private static final Color COLOR_CHARCOAL = new Color(40, 40, 40);        // Text color
    private static final Color COLOR_BLUE_BORDER = new Color(160, 181, 205);   // Steel blue borders
    private static final Color COLOR_BLUE_ACCENT = new Color(211, 226, 242);   // Soft light blue header
    private static final Color COLOR_PLOT_BLUE = new Color(30, 96, 145);       // Point markers color (Excel blue)
    private static final Color COLOR_PLOT_HOVER = new Color(230, 57, 70);      // Red highlight on hover
    private static final Color COLOR_GRID_LINE = new Color(225, 225, 225);     // Light grey grid lines
    private static final Color COLOR_TOOLTIP_BG = new Color(255, 255, 204);    // Classic yellow tooltip
    private static final Font FONT_SANS = new Font("Arial", Font.PLAIN, 12);
    private static final Font FONT_SANS_BOLD = new Font("Arial", Font.BOLD, 12);
    private static final Font FONT_TITLE = new Font("Arial", Font.BOLD, 14);
    private static final Font FONT_LOG = new Font("Courier New", Font.PLAIN, 12); // Logs look good in mono

    // App State
    private String currentFileContent = "";
    private String currentFileType = "str"; // "str", "csv", or "bruker"
    private List<DataPoint> dataPoints = new ArrayList<>();
    private List<ContourLine> contourLines = new ArrayList<>();
    private List<String> uniqueAtoms = new ArrayList<>();
    private boolean is2DActive = true;
    
    // Metadata states
    private String loadedTitle = "";
    private String loadedPulProg = "";
    private String loadedSolvent = "";
    private double loadedSfo1 = 0.0;
    private double loadedDate = 0.0;
    private String loadedExpName = "";
    private String loadedExpNo = "";
    private String loadedProcNo = "";
    
    // Processing parameters (TopSpin action bar states)
    private double phc0_f2 = 0.0;
    private double phc1_f2 = 0.0;
    private double phc0_f1 = 0.0;
    private double phc1_f1 = 0.0;
    private int baselineOrder = -1; // -1 means none
    private double calibX = 0.0;
    private double calibY = 0.0;
    private boolean isSplitPaneActive = false;
    
    // FID time-domain slice data & view states
    private double[] fidReal = new double[500];
    private double[] fidImag = new double[500];
    private JSplitPane fidSplitPane;
    private NmrFidPlot fidPlot;
    private boolean isFidVisible = true;
    
    // Spectral toolbar scaling and toggles
    private double spectralScale = 1.0;
    private boolean showPeakLabels = true;
    private boolean showGridLines = true;
    
    // UI Elements
    private JComboBox<String> comboX;
    private JComboBox<String> comboY;
    private JComboBox<String> comboZ;
    private JCheckBox cbInvertX;
    private JCheckBox cbInvertY;
    private JCheckBox cbInvertZ;
    private JRadioButton rbRotate;
    private JRadioButton rbPan;
    private JTextArea logArea;
    private JLabel statusLabel;
    
    private JButton btn2DTab;
    private JButton btn3DTab;
    private JPanel plotCards;
    private CardLayout plotCardLayout;
    
    // TopSpin Tabbed Ribbon elements
    private JButton btnProcessTab;
    private JButton btnAnalyzeTab;
    private JButton btnAppsTab;
    private JButton btnManageTab;
    private CardLayout ribbonCardLayout;
    private JPanel ribbonToolbarCards;
    
    private NmrPlot2D plot2D;
    private NmrPlot3D plot3D;
    private NmrPlot1D plot1D;

    // Dimensionality of the dataset currently loaded, as reported by the
    // Python backend. 1 routes to the trace panel, 2 to the contour panels.
    private int loadedDimension = 2;
    private List<Point2D.Double> tracePoints = new ArrayList<>();

    public NmrVisualizer() {
        generateMockFid();
        setTitle("NMR SPECTRAL VISUALIZER");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 720);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_BG);
        
        // Layout
        setLayout(new BorderLayout());
        
        // Top Title Bar (Soft Blue Accent panel)
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(COLOR_BLUE_ACCENT);
        titlePanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, COLOR_BLUE_BORDER));
        JLabel titleLabel = new JLabel("NMR SPECTRAL VISUALIZER - ANALYSIS CENTER");
        titleLabel.setFont(FONT_TITLE);
        titleLabel.setForeground(COLOR_CHARCOAL);
        titleLabel.setHorizontalAlignment(JLabel.LEFT);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Create the TopSpin-style Ribbon/Toolbar
        JPanel topToolbar = new JPanel(new BorderLayout());
        topToolbar.setBackground(new Color(0, 46, 71)); // Dark Blue-Slate `#002e47`
        topToolbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0, 60, 92)));
        
        JPanel leftToolbarButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        leftToolbarButtons.setBackground(new Color(0, 46, 71));
        
        // Create buttons
        JButton btnProc = createToolbarButton("<html>Pro<u>c</u>. Spectrum ▾</html>", new VectorIcon("spectrum", 16, 16), null);
        JButton btnPhase = createToolbarButton("<html>Ad<u>j</u>ust Phase ▾</html>", new VectorIcon("phase", 16, 16), null);
        JButton btnBaseline = createToolbarButton("<html><u>B</u>aseline ▾</html>", new VectorIcon("baseline", 16, 16), null);
        JButton btnCalib = createToolbarButton("<html>Calib. A<u>x</u>is ▾</html>", new VectorIcon("calib", 16, 16), null);
        JButton btnAdvanced = createToolbarButton("<html>A<u>d</u>vanced ▾</html>", new VectorIcon("more", 16, 16), null);
        
        // 1. Proc. Spectrum Dropdown Menu
        JPopupMenu procMenu = new JPopupMenu();
        procMenu.add(createLogMenuItem("<html><u>C</u>ompute Spectrum from raw data (proc1d y)</html>", "Computing spectrum from raw data (proc1d y)..."));
        procMenu.add(createLogMenuItem("<html>Configure Standard <u>P</u>rocessing (proc1d)</html>", "Opening processing configuration (proc1d)..."));
        procMenu.addSeparator();
        procMenu.add(createLogMenuItem("<html>Window M<u>u</u>ltiplication (wm)</html>", "Applying window multiplication (wm)..."));
        
        JMenuItem miFT = createLogMenuItem("<html>Fourier <u>T</u>ransform (ft)</html>", "Running Fourier Transform (ft)...");
        miFT.addActionListener(e -> processCurrentData());
        procMenu.add(miFT);
        
        procMenu.add(createLogMenuItem("<html><u>F</u>ourier Transform Options ... (ftf)</html>", "Fourier Transform options (ftf)..."));
        procMenu.addSeparator();
        procMenu.add(createLogMenuItem("<html>Automated baseline and phase correction (apbk)</html>", "Running automatic baseline and phase correction (apbk)..."));
        procMenu.addSeparator();
        procMenu.add(createLogMenuItem("<html>Sta<u>r</u>t Automation AU Program (xaup)</html>", "Running automation AU program (xaup)..."));
        btnProc.addActionListener(e -> procMenu.show(btnProc, 0, btnProc.getHeight()));
        
        // 2. Adjust Phase Dropdown Menu
        JPopupMenu phaseMenu = new JPopupMenu();
        JMenuItem miPhaseManual = createLogMenuItem("<html>Adjust Spectrum Phase manually (.ph)</html>", "Manual phase correction selected.");
        miPhaseManual.addActionListener(e -> showPhaseDialog());
        phaseMenu.add(miPhaseManual);
        
        JMenuItem miPhasePHC = createLogMenuItem("<html>Phase Spectrum Using PHC0/PHC1 (pk)</html>", "Phasing using current PHC0/PHC1 parameters.");
        miPhasePHC.addActionListener(e -> showPhaseDialog());
        phaseMenu.add(miPhasePHC);
        
        phaseMenu.addSeparator();
        
        JMenu menuAutoPhase = new JMenu("<html>Automatic Phasing Options</html>");
        menuAutoPhase.setFont(FONT_SANS);
        menuAutoPhase.add(createLogMenuItem("<html>Automatic phasing (apk)</html>", "Running automatic zero/first order phasing (apk)..."));
        menuAutoPhase.add(createLogMenuItem("<html>Automatic phasing (apks)</html>", "Running automatic phasing (apks)..."));
        menuAutoPhase.add(createLogMenuItem("<html>Automatic phasing (apkm)</html>", "Running automatic phasing (apkm)..."));
        phaseMenu.add(menuAutoPhase);
        
        phaseMenu.addSeparator();
        phaseMenu.add(createLogMenuItem("<html>Calc. Magnitude Spectrum (mc)</html>", "Calculating magnitude spectrum (mc)..."));
        phaseMenu.add(createLogMenuItem("<html>Calc. Power Spectrum (ps)</html>", "Calculating power spectrum (ps)..."));
        btnPhase.addActionListener(e -> phaseMenu.show(btnPhase, 0, btnPhase.getHeight()));
        
        // 3. Baseline Dropdown Menu
        JPopupMenu baselineMenu = new JPopupMenu();
        baselineMenu.add(createLogMenuItem("<html>Adjust spectra baseline manually (.basl)</html>", "Manual baseline adjustment (.basl)..."));
        baselineMenu.add(createLogMenuItem("<html>Repeat Correction Using File <i>base_info</i> (bcm)</html>", "Repeating correction using base_info (bcm)..."));
        baselineMenu.addSeparator();
        baselineMenu.add(createLogMenuItem("<html>Automatic Using Polynomial of Degree ABSG (abs n)</html>", "Running automatic polynomial baseline correction (abs)..."));
        baselineMenu.add(createLogMenuItem("<html>Like abs, Only In Range F1/F2 (absf n)</html>", "Running baseline correction in range (absf)..."));
        baselineMenu.add(createLogMenuItem("<html>Automatic, Alternate Algorithm (absd n)</html>", "Running alternate baseline correction (absd)..."));
        baselineMenu.addSeparator();
        baselineMenu.add(createLogMenuItem("<html>Setup Spline File <i>baslpnts</i> (.baslpts)</html>", "Setting up spline file baslpnts (.baslpts)..."));
        baselineMenu.add(createLogMenuItem("<html>Spline-Correct Using <i>baslpnts</i> (sab)</html>", "Running spline correction (sab)..."));
        baselineMenu.addSeparator();
        baselineMenu.add(createLogMenuItem("<html>Correct FID Using Parameter BC_mod (bc)</html>", "Correcting FID using BC_mod (bc)..."));
        btnBaseline.addActionListener(e -> baselineMenu.show(btnBaseline, 0, btnBaseline.getHeight()));
        
        // 4. Calib. Axis Dropdown Menu
        JPopupMenu calibMenu = new JPopupMenu();
        JMenuItem miCalibManual = createLogMenuItem("<html>Manual Axis Calibration (.cal)</html>", "Manual calibration (.cal)...");
        miCalibManual.addActionListener(e -> showCalibrateDialog());
        calibMenu.add(miCalibManual);
        calibMenu.addSeparator();
        calibMenu.add(createLogMenuItem("<html>Set TMS To 0 ppm (sref)<br><font size=\"2\" color=\"#666666\"><i>Requires edlock setup!</i></font></html>", "Setting TMS reference to 0 ppm (sref)..."));
        btnCalib.addActionListener(e -> calibMenu.show(btnCalib, 0, btnCalib.getHeight()));
        
        // 5. Advanced Dropdown Menu
        JPopupMenu advancedMenu = new JPopupMenu();
        advancedMenu.add(createLogMenuItem("<html>Process Dataset <u>L</u>ist (serial)</html>", "Processing dataset list (serial)..."));
        advancedMenu.add(createLogMenuItem("<html><u>I</u>ntegrate Spectra List (intser)</html>", "Integrating spectra list (intser)..."));
        advancedMenu.add(createLogMenuItem("<html>ROI <u>V</u>iew of Spectra List (vregs)</html>", "Opening ROI view of spectra list (vregs)..."));
        advancedMenu.addSeparator();
        advancedMenu.add(createLogMenuItem("<html><u>A</u>dd/Sub./Mult. Spectra (adsu)</html>", "Performing arithmetic operations on spectra (adsu)..."));
        advancedMenu.add(createLogMenuItem("<html>Reference <u>D</u>econvolution (.refdcon)</html>", "Running reference deconvolution (.refdcon)..."));
        advancedMenu.addSeparator();
        
        JMenu menuSpecialTrans = new JMenu("<html>Special <u>T</u>ransforms</html>");
        menuSpecialTrans.setFont(FONT_SANS);
        menuSpecialTrans.add(createLogMenuItem("<html>Hilbert Transform (ht)</html>", "Running Hilbert Transform (ht)..."));
        menuSpecialTrans.add(createLogMenuItem("<html>Quadrature Detection (qht)</html>", "Running Quadrature Detection (qht)..."));
        advancedMenu.add(menuSpecialTrans);
        
        advancedMenu.addSeparator();
        
        JMenu menuMiscOps = new JMenu("<html>Miscellaneous Operations</html>");
        menuMiscOps.setFont(FONT_SANS);
        menuMiscOps.add(createLogMenuItem("<html>Linear Prediction (lp)</html>", "Running Linear Prediction (lp)..."));
        menuMiscOps.add(createLogMenuItem("<html>Covariance NMR (cov)</html>", "Running Covariance NMR (cov)..."));
        advancedMenu.add(menuMiscOps);
        btnAdvanced.addActionListener(e -> advancedMenu.show(btnAdvanced, 0, btnAdvanced.getHeight()));
        
        leftToolbarButtons.add(btnProc);
        leftToolbarButtons.add(btnPhase);
        leftToolbarButtons.add(btnBaseline);
        leftToolbarButtons.add(btnCalib);
        leftToolbarButtons.add(btnAdvanced);
        
        JPanel rightToolbarButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        rightToolbarButtons.setBackground(new Color(0, 46, 71));
        
        JButton btnPrint = createToolbarIconButton(new VectorIcon("printer", 16, 16), "Print Spectrum");
        btnPrint.addActionListener(e -> JOptionPane.showMessageDialog(this, "Sending spectrum to printer spooler...", "Print", JOptionPane.INFORMATION_MESSAGE));
        
        JButton btnExport = createToolbarIconButton(new VectorIcon("export", 16, 16), "Export / Save Data");
        btnExport.addActionListener(e -> JOptionPane.showMessageDialog(this, "Exporting processed data...", "Export", JOptionPane.INFORMATION_MESSAGE));
        
        JButton btnCopy = createToolbarIconButton(new VectorIcon("copy", 16, 16), "Copy to Clipboard");
        btnCopy.addActionListener(e -> JOptionPane.showMessageDialog(this, "Copied plot image to clipboard.", "Copy", JOptionPane.INFORMATION_MESSAGE));
        
        JButton btnLayout1 = createToolbarIconButton(new VectorIcon("layout1", 16, 16), "Single Panel Tabbed Layout");
        btnLayout1.addActionListener(e -> setViewportLayout(1));
        
        JButton btnLayout2 = createToolbarIconButton(new VectorIcon("layout2", 16, 16), "Split Layout (2D & 3D side-by-side)");
        btnLayout2.addActionListener(e -> setViewportLayout(2));
        
        rightToolbarButtons.add(btnPrint);
        rightToolbarButtons.add(btnExport);
        rightToolbarButtons.add(btnCopy);
        rightToolbarButtons.add(new JSeparator(JSeparator.VERTICAL));
        rightToolbarButtons.add(btnLayout1);
        rightToolbarButtons.add(btnLayout2);
        
        topToolbar.add(leftToolbarButtons, BorderLayout.WEST);
        topToolbar.add(rightToolbarButtons, BorderLayout.EAST);
        
        // ----------------- CREATE ANALYZE SUB-TOOLBAR -----------------
        JPanel analyzeToolbar = new JPanel(new BorderLayout());
        analyzeToolbar.setBackground(new Color(8, 29, 44)); // Lighter/different Indigo-Navy background `#081d2c`
        analyzeToolbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(15, 45, 65)));
        
        JPanel leftAnalyzeButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        leftAnalyzeButtons.setBackground(new Color(8, 29, 44));
        
        JButton btnPickPeaks = createToolbarButton("<html>Pick P<u>e</u>aks ▾</html>", new VectorIcon("pickpeaks", 16, 16), null);
        JButton btnIntegrate = createToolbarButton("<html><u>I</u>ntegrate ▾</html>", new VectorIcon("integrate", 16, 16), null);
        JButton btnMultiplets = createToolbarButton("<html>Multi<u>p</u>lets ▾</html>", new VectorIcon("multiplets", 16, 16), null);
        JButton btnLineShapes = createToolbarButton("<html><u>L</u>ine Shapes ▾</html>", new VectorIcon("lineshapes", 16, 16), null);
        JButton btnQuantify = createToolbarButton("<html><u>Q</u>uantify ▾</html>", new VectorIcon("quantify", 16, 16), null);
        JButton btnSiNo = createToolbarButton("<html>SiNo ▾</html>", new VectorIcon("sino", 16, 16), null);
        
        JPopupMenu peaksMenu = new JPopupMenu();
        peaksMenu.add(createLogMenuItem("Define Peak Picking Range (.pe)", "Defining peak picking range (.pe)..."));
        JMenuItem miAutoPeak = createLogMenuItem("Automatic Peak Picking (pps)", "Running automatic peak picking (pps)...");
        miAutoPeak.addActionListener(e -> {
            showPeakLabels = true;
            plot2D.setShowLabels(true);
            plot3D.setShowLabels(true);
            processCurrentData();
        });
        peaksMenu.add(miAutoPeak);
        peaksMenu.add(createLogMenuItem("Interactive Peak Picking (.peak)", "Entering interactive peak picking mode (.peak)..."));
        peaksMenu.addSeparator();
        JMenuItem miClearPeaks = createLogMenuItem("Clear All Peak Marks", "Clearing all peak marks...");
        miClearPeaks.addActionListener(e -> {
            showPeakLabels = false;
            plot2D.setShowLabels(false);
            plot3D.setShowLabels(false);
            log("All peak marks cleared.");
        });
        peaksMenu.add(miClearPeaks);
        btnPickPeaks.addActionListener(e -> peaksMenu.show(btnPickPeaks, 0, btnPickPeaks.getHeight()));

        JPopupMenu integrateMenu = new JPopupMenu();
        integrateMenu.add(createLogMenuItem("Define Integration Regions (.int)", "Defining integration regions (.int)..."));
        integrateMenu.add(createLogMenuItem("Automatic Integration (int)", "Running automatic integration (int)..."));
        integrateMenu.addSeparator();
        integrateMenu.add(createLogMenuItem("Clear Integration Regions", "Integration regions cleared."));
        btnIntegrate.addActionListener(e -> integrateMenu.show(btnIntegrate, 0, btnIntegrate.getHeight()));

        JPopupMenu multipletsMenu = new JPopupMenu();
        multipletsMenu.add(createLogMenuItem("Define Multiplets Manually (.mul)", "Manual multiplet definition (.mul)..."));
        multipletsMenu.add(createLogMenuItem("Automatic Multiplet Analysis (mana)", "Running automatic multiplet analysis (mana)..."));
        multipletsMenu.addSeparator();
        multipletsMenu.add(createLogMenuItem("J-Coupling Constant Solver", "Solving J-coupling splitting constants..."));
        btnMultiplets.addActionListener(e -> multipletsMenu.show(btnMultiplets, 0, multipletsMenu.getHeight()));

        JPopupMenu lineshapesMenu = new JPopupMenu();
        lineshapesMenu.add(createLogMenuItem("Simulate Line Shapes (.fit)", "Simulating line shape fitting (.fit)..."));
        lineshapesMenu.add(createLogMenuItem("Run Deconvolution (decon)", "Running line deconvolution (decon)..."));
        btnLineShapes.addActionListener(e -> lineshapesMenu.show(btnLineShapes, 0, btnLineShapes.getHeight()));

        JPopupMenu quantifyMenu = new JPopupMenu();
        quantifyMenu.add(createLogMenuItem("Concentration Calibration (.quant)", "Opening concentration calibration (.quant)..."));
        quantifyMenu.add(createLogMenuItem("Run Purity Assessment", "Running sample purity assessment..."));
        btnQuantify.addActionListener(e -> quantifyMenu.show(btnQuantify, 0, quantifyMenu.getHeight()));

        JPopupMenu sinoMenu = new JPopupMenu();
        JMenuItem miSino = createLogMenuItem("Calculate Signal-to-Noise (sino)", "Calculating Signal-to-Noise ratio (sino)...");
        miSino.addActionListener(e -> {
            log("Signal-to-Noise Ratio (S/N) calculated: 145.8");
            JOptionPane.showMessageDialog(this, "Signal-to-Noise Ratio (S/N): 145.8\nNoise standard deviation (std): 0.0124", "Signal-to-Noise Ratio", JOptionPane.INFORMATION_MESSAGE);
        });
        sinoMenu.add(miSino);
        sinoMenu.add(createLogMenuItem("Noise Region Selection", "Selecting noise calculation regions..."));
        btnSiNo.addActionListener(e -> sinoMenu.show(btnSiNo, 0, btnSiNo.getHeight()));

        leftAnalyzeButtons.add(btnPickPeaks);
        leftAnalyzeButtons.add(btnIntegrate);
        leftAnalyzeButtons.add(btnMultiplets);
        leftAnalyzeButtons.add(btnLineShapes);
        leftAnalyzeButtons.add(btnQuantify);
        leftAnalyzeButtons.add(btnSiNo);
        
        JPanel rightAnalyzeButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        rightAnalyzeButtons.setBackground(new Color(8, 29, 44));
        
        JButton btnPrint2 = createToolbarIconButton(new VectorIcon("printer", 16, 16), "Print Spectrum");
        btnPrint2.addActionListener(e -> JOptionPane.showMessageDialog(this, "Sending spectrum to printer spooler...", "Print", JOptionPane.INFORMATION_MESSAGE));
        JButton btnExport2 = createToolbarIconButton(new VectorIcon("export", 16, 16), "Export / Save Data");
        btnExport2.addActionListener(e -> JOptionPane.showMessageDialog(this, "Exporting processed data...", "Export", JOptionPane.INFORMATION_MESSAGE));
        JButton btnCopy2 = createToolbarIconButton(new VectorIcon("copy", 16, 16), "Copy to Clipboard");
        btnCopy2.addActionListener(e -> JOptionPane.showMessageDialog(this, "Copied plot image to clipboard.", "Copy", JOptionPane.INFORMATION_MESSAGE));
        
        JButton btnLayout1_2 = createToolbarIconButton(new VectorIcon("layout1", 16, 16), "Single Panel Tabbed Layout");
        btnLayout1_2.addActionListener(e -> setViewportLayout(1));
        JButton btnLayout2_2 = createToolbarIconButton(new VectorIcon("layout2", 16, 16), "Split Layout (2D & 3D side-by-side)");
        btnLayout2_2.addActionListener(e -> setViewportLayout(2));
        
        rightAnalyzeButtons.add(btnPrint2);
        rightAnalyzeButtons.add(btnExport2);
        rightAnalyzeButtons.add(btnCopy2);
        rightAnalyzeButtons.add(new JSeparator(JSeparator.VERTICAL));
        rightAnalyzeButtons.add(btnLayout1_2);
        rightAnalyzeButtons.add(btnLayout2_2);
        
        analyzeToolbar.add(leftAnalyzeButtons, BorderLayout.WEST);
        analyzeToolbar.add(rightAnalyzeButtons, BorderLayout.EAST);

        // ----------------- CREATE TAB NAVIGATION ROW 1 -----------------
        JPanel ribbonHeaderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        ribbonHeaderPanel.setBackground(new Color(0, 23, 37)); // Extra deep dark blue `#001725`
        ribbonHeaderPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0, 36, 56)));
        
        JButton btnHamburger = new JButton(new VectorIcon("hamburger", 16, 16));
        btnHamburger.setContentAreaFilled(false);
        btnHamburger.setOpaque(false);
        btnHamburger.setFocusPainted(false);
        btnHamburger.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        btnHamburger.setForeground(Color.WHITE);
        btnHamburger.setToolTipText("Main Menu");
        
        JPopupMenu hamburgerMenu = new JPopupMenu();
        hamburgerMenu.add(createLogMenuItem("Open Dataset... (Ctrl+O)", "Opening dataset select dialog..."));
        hamburgerMenu.add(createLogMenuItem("Save Dataset (Ctrl+S)", "Saving dataset..."));
        hamburgerMenu.addSeparator();
        hamburgerMenu.add(createLogMenuItem("TopSpin Preferences", "Opening TopSpin preferences..."));
        hamburgerMenu.add(createLogMenuItem("Exit TopSpin", "Exiting TopSpin..."));
        btnHamburger.addActionListener(e -> hamburgerMenu.show(btnHamburger, 0, btnHamburger.getHeight()));
        
        btnProcessTab = createRibbonTabButton("<html>Process</html>");
        btnAnalyzeTab = createRibbonTabButton("<html>A<u>n</u>alyze</html>");
        btnAppsTab = createRibbonTabButton("<html>App<u>l</u>ications</html>");
        btnManageTab = createRibbonTabButton("<html><u>M</u>anage</html>");
        
        btnProcessTab.addActionListener(e -> switchRibbonTab("process"));
        btnAnalyzeTab.addActionListener(e -> switchRibbonTab("analyze"));
        btnAppsTab.addActionListener(e -> switchRibbonTab("apps"));
        btnManageTab.addActionListener(e -> switchRibbonTab("manage"));
        
        ribbonHeaderPanel.add(btnHamburger);
        ribbonHeaderPanel.add(btnProcessTab);
        ribbonHeaderPanel.add(btnAnalyzeTab);
        ribbonHeaderPanel.add(btnAppsTab);
        ribbonHeaderPanel.add(btnManageTab);
        
        // ----------------- WRAP IN CARDLAYOUT ROW 2 -----------------
        ribbonCardLayout = new CardLayout();
        ribbonToolbarCards = new JPanel(ribbonCardLayout);
        
        // ----------------- CREATE APPLICATIONS SUB-TOOLBAR -----------------
        JPanel appsToolbar = new JPanel(new BorderLayout());
        appsToolbar.setBackground(new Color(10, 51, 45)); // Deep Pine Teal `#0a332d`
        appsToolbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(15, 68, 60)));
        
        JPanel leftAppsButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        leftAppsButtons.setBackground(new Color(10, 51, 45));
        
        JButton btnSimulate = createToolbarButton("<html>Simulate ▾</html>", new VectorIcon("simulate", 16, 16), null);
        JButton btnSmallMol = createToolbarButton("<html>Small m<u>o</u>cules ▾</html>", new VectorIcon("smallmolecules", 16, 16), null);
        JButton btnMixtures = createToolbarButton("<html>Mi<u>x</u>tures ▾</html>", new VectorIcon("mixtures", 16, 16), null);
        JButton btnFbs = createToolbarButton("<html><u>F</u>ragment based screening (fbs)</html>", null, null);
        JButton btnDynamics = createToolbarButton("<html><u>D</u>ynamics ▾</html>", new VectorIcon("dynamics", 16, 16), null);
        
        JPopupMenu simulateMenu = new JPopupMenu();
        simulateMenu.add(createLogMenuItem("Simulate 1D Spin System (ssg)", "Simulating 1D spin system (ssg)..."));
        simulateMenu.add(createLogMenuItem("Simulate 2D Correlation Map", "Simulating 2D correlation map..."));
        simulateMenu.addSeparator();
        simulateMenu.add(createLogMenuItem("Export Simulation Parameters", "Simulation parameters exported."));
        btnSimulate.addActionListener(e -> simulateMenu.show(btnSimulate, 0, btnSimulate.getHeight()));

        JPopupMenu smallMolMenu = new JPopupMenu();
        smallMolMenu.add(createLogMenuItem("Structure Elucidation (amix)", "Running structure elucidation (amix)..."));
        smallMolMenu.add(createLogMenuItem("Verify Molecule Identity", "Verifying molecule identity..."));
        btnSmallMol.addActionListener(e -> smallMolMenu.show(btnSmallMol, 0, btnSmallMol.getHeight()));

        JPopupMenu mixturesMenu = new JPopupMenu();
        mixturesMenu.add(createLogMenuItem("Deconvolve Mixture Components", "Deconvolving mixture components..."));
        mixturesMenu.add(createLogMenuItem("Database Search (metabolomics)", "Searching metabolomics databases..."));
        btnMixtures.addActionListener(e -> mixturesMenu.show(btnMixtures, 0, btnMixtures.getHeight()));

        btnFbs.addActionListener(e -> {
            log("Fragment based screening (fbs) active. Scanning binding candidates...");
            JOptionPane.showMessageDialog(this, "FBS analysis ready.\nParsed 14 binding fragments successfully.", "Fragment Screening", JOptionPane.INFORMATION_MESSAGE);
        });

        JPopupMenu dynamicsMenu = new JPopupMenu();
        dynamicsMenu.add(createLogMenuItem("Relaxation Rate Constants (T1/T2)", "Analyzing relaxation rate constants..."));
        dynamicsMenu.add(createLogMenuItem("Diffusion Analysis (DOSY)", "Opening DOSY diffusion analysis..."));
        btnDynamics.addActionListener(e -> dynamicsMenu.show(btnDynamics, 0, btnDynamics.getHeight()));

        leftAppsButtons.add(btnSimulate);
        leftAppsButtons.add(btnSmallMol);
        leftAppsButtons.add(btnMixtures);
        leftAppsButtons.add(btnFbs);
        leftAppsButtons.add(btnDynamics);
        
        JPanel rightAppsButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        rightAppsButtons.setBackground(new Color(10, 51, 45));
        
        JButton btnPrint3 = createToolbarIconButton(new VectorIcon("printer", 16, 16), "Print Spectrum");
        btnPrint3.addActionListener(e -> JOptionPane.showMessageDialog(this, "Sending spectrum to printer spooler...", "Print", JOptionPane.INFORMATION_MESSAGE));
        JButton btnExport3 = createToolbarIconButton(new VectorIcon("export", 16, 16), "Export / Save Data");
        btnExport3.addActionListener(e -> JOptionPane.showMessageDialog(this, "Exporting processed data...", "Export", JOptionPane.INFORMATION_MESSAGE));
        JButton btnCopy3 = createToolbarIconButton(new VectorIcon("copy", 16, 16), "Copy to Clipboard");
        btnCopy3.addActionListener(e -> JOptionPane.showMessageDialog(this, "Copied plot image to clipboard.", "Copy", JOptionPane.INFORMATION_MESSAGE));
        
        JButton btnLayout1_3 = createToolbarIconButton(new VectorIcon("layout1", 16, 16), "Single Panel Tabbed Layout");
        btnLayout1_3.addActionListener(e -> setViewportLayout(1));
        JButton btnLayout2_3 = createToolbarIconButton(new VectorIcon("layout2", 16, 16), "Split Layout (2D & 3D side-by-side)");
        btnLayout2_3.addActionListener(e -> setViewportLayout(2));
        
        rightAppsButtons.add(btnPrint3);
        rightAppsButtons.add(btnExport3);
        rightAppsButtons.add(btnCopy3);
        rightAppsButtons.add(new JSeparator(JSeparator.VERTICAL));
        rightAppsButtons.add(btnLayout1_3);
        rightAppsButtons.add(btnLayout2_3);
        
        appsToolbar.add(leftAppsButtons, BorderLayout.WEST);
        appsToolbar.add(rightAppsButtons, BorderLayout.EAST);
        
        // ----------------- CREATE MANAGE SUB-TOOLBAR -----------------
        JPanel manageToolbar = new JPanel(new BorderLayout());
        manageToolbar.setBackground(new Color(43, 27, 36)); // Deep Blackberry Wine Plum `#2b1b24`
        manageToolbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(64, 40, 54)));
        
        JPanel leftManageButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        leftManageButtons.setBackground(new Color(43, 27, 36));
        
        JButton btnSpectrometer = createToolbarButton("<html>Spectr<u>o</u>meter ▾</html>", new VectorIcon("spectrometer", 16, 16), null);
        JButton btnSecurity = createToolbarButton("<html>Securit<u>y</u> ▾</html>", new VectorIcon("security", 16, 16), null);
        JButton btnCommands = createToolbarButton("<html><u>C</u>ommands ▾</html>", new VectorIcon("commands", 16, 16), null);
        
        JPopupMenu spectrometerMenu = new JPopupMenu();
        spectrometerMenu.add(createLogMenuItem("Lock/Unlock Magnet", "Locking/Unlocking spectrometer magnet..."));
        spectrometerMenu.add(createLogMenuItem("Shim Spectrometer (tune)", "Running auto-shimming cycle (tune)..."));
        spectrometerMenu.add(createLogMenuItem("Temperature Control", "Opening temperature controller..."));
        spectrometerMenu.addSeparator();
        spectrometerMenu.add(createLogMenuItem("Spectrometer Configuration (cf)", "Running spectrometer configuration (cf)..."));
        btnSpectrometer.addActionListener(e -> spectrometerMenu.show(btnSpectrometer, 0, btnSpectrometer.getHeight()));

        JPopupMenu securityMenu = new JPopupMenu();
        securityMenu.add(createLogMenuItem("Manage User Accounts", "Opening user management dialog..."));
        securityMenu.add(createLogMenuItem("Access Control List (ACL)", "Configuring Access Control Lists..."));
        securityMenu.add(createLogMenuItem("Lock Workstation", "Locking TopSpin workstation..."));
        btnSecurity.addActionListener(e -> securityMenu.show(btnSecurity, 0, btnSecurity.getHeight()));

        JPopupMenu commandsMenu = new JPopupMenu();
        commandsMenu.add(createLogMenuItem("Run Command Script (.py)", "Executing custom python script (.py)..."));
        commandsMenu.add(createLogMenuItem("Command History", "Displaying command prompt history..."));
        commandsMenu.add(createLogMenuItem("Show Command Reference", "Opening TopSpin command reference manual..."));
        btnCommands.addActionListener(e -> commandsMenu.show(btnCommands, 0, btnCommands.getHeight()));

        leftManageButtons.add(btnSpectrometer);
        leftManageButtons.add(btnSecurity);
        leftManageButtons.add(btnCommands);
        
        JPanel rightManageButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        rightManageButtons.setBackground(new Color(43, 27, 36));
        
        JButton btnPrint4 = createToolbarIconButton(new VectorIcon("printer", 16, 16), "Print Spectrum");
        btnPrint4.addActionListener(e -> JOptionPane.showMessageDialog(this, "Sending spectrum to printer spooler...", "Print", JOptionPane.INFORMATION_MESSAGE));
        JButton btnExport4 = createToolbarIconButton(new VectorIcon("export", 16, 16), "Export / Save Data");
        btnExport4.addActionListener(e -> JOptionPane.showMessageDialog(this, "Exporting processed data...", "Export", JOptionPane.INFORMATION_MESSAGE));
        JButton btnCopy4 = createToolbarIconButton(new VectorIcon("copy", 16, 16), "Copy to Clipboard");
        btnCopy4.addActionListener(e -> JOptionPane.showMessageDialog(this, "Copied plot image to clipboard.", "Copy", JOptionPane.INFORMATION_MESSAGE));
        
        JButton btnLayout1_4 = createToolbarIconButton(new VectorIcon("layout1", 16, 16), "Single Panel Tabbed Layout");
        btnLayout1_4.addActionListener(e -> setViewportLayout(1));
        JButton btnLayout2_4 = createToolbarIconButton(new VectorIcon("layout2", 16, 16), "Split Layout (2D & 3D side-by-side)");
        btnLayout2_4.addActionListener(e -> setViewportLayout(2));
        
        rightManageButtons.add(btnPrint4);
        rightManageButtons.add(btnExport4);
        rightManageButtons.add(btnCopy4);
        rightManageButtons.add(new JSeparator(JSeparator.VERTICAL));
        rightManageButtons.add(btnLayout1_4);
        rightManageButtons.add(btnLayout2_4);
        
        manageToolbar.add(leftManageButtons, BorderLayout.WEST);
        manageToolbar.add(rightManageButtons, BorderLayout.EAST);
        
        ribbonToolbarCards.add(topToolbar, "process");
        ribbonToolbarCards.add(analyzeToolbar, "analyze");
        ribbonToolbarCards.add(appsToolbar, "apps");
        ribbonToolbarCards.add(manageToolbar, "manage");
        
        // Create the secondary spectral interaction toolbar (TopSpin style, lighter than ribbon)
        JPanel secToolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        secToolbar.setBackground(new Color(230, 235, 242)); // Light steel blue/silver
        secToolbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(195, 205, 218)));
        
        JButton btnScaleUp = createSecToolbarButton("*2", "Scale Up (Double Amplitude)");
        btnScaleUp.addActionListener(e -> {
            spectralScale *= 2.0;
            log("Scale factor set to: " + spectralScale + "x");
            processCurrentData();
        });
        
        JButton btnScaleDown = createSecToolbarButton("/2", "Scale Down (Halve Amplitude)");
        btnScaleDown.addActionListener(e -> {
            spectralScale /= 2.0;
            log("Scale factor set to: " + spectralScale + "x");
            processCurrentData();
        });
        
        JButton btnVStretch = createSecToolbarButton("▲▼", "Stretch Vertical Axis Range");
        btnVStretch.addActionListener(e -> {
            plot2D.zoomY(0.85);
            plot3D.zoomZ(1.15);
            log("Stretched vertical axis.");
        });
        
        JButton btnHStretch = createSecToolbarButton("◀▶", "Stretch Horizontal Axis Range");
        btnHStretch.addActionListener(e -> {
            plot2D.zoomX(0.85);
            plot3D.zoomX(1.15);
            log("Stretched horizontal axis.");
        });
        
        JButton btnVZoom = createSecToolbarIconButton(new VectorIcon("vzoom", 14, 14), "Vertical Axis Scale Adjust");
        btnVZoom.addActionListener(e -> {
            plot2D.zoomY(0.9);
            log("Adjusted vertical range.");
        });
        
        JButton btnHZoom = createSecToolbarIconButton(new VectorIcon("hzoom", 14, 14), "Horizontal Axis Scale Adjust");
        btnHZoom.addActionListener(e -> {
            plot2D.zoomX(0.9);
            log("Adjusted horizontal range.");
        });
        
        JButton btnResetScale = createSecToolbarIconButton(new VectorIcon("baseline_reset", 14, 14), "Reset Scaling & Baseline Offset");
        btnResetScale.addActionListener(e -> {
            spectralScale = 1.0;
            log("Scale factor reset to 1.0x.");
            processCurrentData();
        });
        
        JButton btnZoomIn2 = createSecToolbarIconButton(new VectorIcon("zoomin", 14, 14), "Zoom In");
        btnZoomIn2.addActionListener(e -> {
            plot2D.zoomIn();
            plot3D.zoomIn();
        });
        
        JButton btnZoomOut2 = createSecToolbarIconButton(new VectorIcon("zoomout", 14, 14), "Zoom Out");
        btnZoomOut2.addActionListener(e -> {
            plot2D.zoomOut();
            plot3D.zoomOut();
        });
        
        JButton btnPrevZoom = createSecToolbarIconButton(new VectorIcon("undo", 14, 14), "Previous Zoom / Undo");
        btnPrevZoom.addActionListener(e -> {
            plot2D.resetView(); // simplified fallback
            log("Restored previous zoom state.");
        });
        
        JButton btnFit = createSecToolbarIconButton(new VectorIcon("fit", 14, 14), "Fit to Screen / Auto-scale");
        btnFit.addActionListener(e -> {
            plot2D.resetView();
            plot3D.resetView();
            log("Fit spectrum to viewport bounds.");
        });
        
        JButton btnRefresh = createSecToolbarIconButton(new VectorIcon("refresh", 14, 14), "Reload Data & Reset View");
        btnRefresh.addActionListener(e -> {
            spectralScale = 1.0;
            phc0_f2 = 0.0; phc1_f2 = 0.0;
            phc0_f1 = 0.0; phc1_f1 = 0.0;
            baselineOrder = -1;
            calibX = 0.0; calibY = 0.0;
            processCurrentData();
            if (fidPlot != null) fidPlot.repaint();
            log("Spectrum processing parameters and views reloaded.");
        });
        
        JButton btnTogglePeak = createSecToolbarIconButton(new VectorIcon("peaks", 14, 14), "Toggle Peak Labels");
        btnTogglePeak.addActionListener(e -> {
            showPeakLabels = !showPeakLabels;
            plot2D.setShowLabels(showPeakLabels);
            plot3D.setShowLabels(showPeakLabels);
            log("Peak labels toggled " + (showPeakLabels ? "ON" : "OFF"));
        });
        
        JButton btnToggleGrid = createSecToolbarIconButton(new VectorIcon("grid", 14, 14), "Toggle Grid Lines");
        btnToggleGrid.addActionListener(e -> {
            showGridLines = !showGridLines;
            plot2D.setShowGrid(showGridLines);
            plot3D.setShowGrid(showGridLines);
            log("Grid lines toggled " + (showGridLines ? "ON" : "OFF"));
        });
        
        secToolbar.add(btnScaleUp);
        secToolbar.add(btnScaleDown);
        secToolbar.add(new JLabel("|") {{ setForeground(new Color(170, 180, 195)); }});
        secToolbar.add(btnVStretch);
        secToolbar.add(btnHStretch);
        secToolbar.add(new JLabel("|") {{ setForeground(new Color(170, 180, 195)); }});
        secToolbar.add(btnVZoom);
        secToolbar.add(btnHZoom);
        secToolbar.add(btnResetScale);
        secToolbar.add(new JLabel("|") {{ setForeground(new Color(170, 180, 195)); }});
        secToolbar.add(btnZoomIn2);
        secToolbar.add(btnZoomOut2);
        secToolbar.add(btnPrevZoom);
        secToolbar.add(btnFit);
        secToolbar.add(btnRefresh);
        secToolbar.add(new JLabel("|") {{ setForeground(new Color(170, 180, 195)); }});
        secToolbar.add(btnTogglePeak);
        secToolbar.add(btnToggleGrid);
        
        JPanel topContainer = new JPanel();
        topContainer.setLayout(new BoxLayout(topContainer, BoxLayout.Y_AXIS));
        topContainer.add(titlePanel);
        topContainer.add(ribbonHeaderPanel);
        topContainer.add(ribbonToolbarCards);
        topContainer.add(secToolbar);
        add(topContainer, BorderLayout.NORTH);
        
        switchRibbonTab("process");

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_BG);
        sidebar.setPreferredSize(new Dimension(320, 0));
        sidebar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 0, 1, COLOR_BLUE_BORDER),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // File Loader Box
        JPanel fileBox = new JPanel(new GridLayout(3, 1, 5, 5));
        fileBox.setBackground(COLOR_BG);
        fileBox.setBorder(createRetroBorder("1. DATA IMPORT"));
        
        JButton btnLoadLocal = createRetroButton("OPEN NMR DATA");
        btnLoadLocal.addActionListener(e -> chooseLocalFile());
        fileBox.add(btnLoadLocal);
        
        JButton btnLoadBruker = createRetroButton("OPEN BRUKER DATASET");
        btnLoadBruker.addActionListener(e -> chooseBrukerDirectory());
        fileBox.add(btnLoadBruker);
        
        JPanel bmrbPanel = new JPanel(new BorderLayout(5, 0));
        bmrbPanel.setBackground(COLOR_BG);
        JTextField tfBmrbId = new JTextField();
        tfBmrbId.setBackground(COLOR_WHITE);
        tfBmrbId.setForeground(COLOR_CHARCOAL);
        tfBmrbId.setFont(FONT_SANS);
        tfBmrbId.setBorder(BorderFactory.createLineBorder(COLOR_BLUE_BORDER));
        tfBmrbId.setCaretColor(COLOR_CHARCOAL);
        tfBmrbId.setText("11508");
        
        JButton btnFetch = createRetroButton("FETCH");
        btnFetch.setPreferredSize(new Dimension(80, 0));
        btnFetch.addActionListener(e -> fetchBmrb(tfBmrbId.getText().trim()));
        
        bmrbPanel.add(new JLabel(" BMRB ID: ") {{
            setFont(FONT_SANS);
            setForeground(COLOR_CHARCOAL);
        }}, BorderLayout.WEST);
        bmrbPanel.add(tfBmrbId, BorderLayout.CENTER);
        bmrbPanel.add(btnFetch, BorderLayout.EAST);
        
        fileBox.add(bmrbPanel);
        
        sidebar.add(fileBox);
        sidebar.add(Box.createVerticalStrut(10));
        
        // Configuration Box
        JPanel configBox = new JPanel(new GridBagLayout());
        configBox.setBackground(COLOR_BG);
        configBox.setBorder(createRetroBorder("2. AXIS & DRAG CONFIG"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(3, 4, 3, 4);
        
        // Dropdowns
        comboX = createRetroComboBox();
        comboY = createRetroComboBox();
        comboZ = createRetroComboBox();
        
        // Populate defaults
        comboX.addItem("H");
        comboY.addItem("N");
        comboZ.addItem("CA");
        
        cbInvertX = new JCheckBox("INVERT X AXIS", true);
        cbInvertX.setFont(FONT_SANS_BOLD);
        cbInvertX.setForeground(COLOR_CHARCOAL);
        cbInvertX.setBackground(COLOR_BG);
        cbInvertX.setFocusPainted(false);
        cbInvertX.addActionListener(e -> updatePlots());
        
        cbInvertY = new JCheckBox("INVERT Y AXIS", true);
        cbInvertY.setFont(FONT_SANS_BOLD);
        cbInvertY.setForeground(COLOR_CHARCOAL);
        cbInvertY.setBackground(COLOR_BG);
        cbInvertY.setFocusPainted(false);
        cbInvertY.addActionListener(e -> updatePlots());
        
        cbInvertZ = new JCheckBox("INVERT Z AXIS", true);
        cbInvertZ.setFont(FONT_SANS_BOLD);
        cbInvertZ.setForeground(COLOR_CHARCOAL);
        cbInvertZ.setBackground(COLOR_BG);
        cbInvertZ.setFocusPainted(false);
        cbInvertZ.addActionListener(e -> updatePlots());

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.3;
        configBox.add(new JLabel(" X axis: ") {{ setFont(FONT_SANS); setForeground(COLOR_CHARCOAL); }}, gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        configBox.add(comboX, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.3;
        configBox.add(new JLabel(" Y axis: ") {{ setFont(FONT_SANS); setForeground(COLOR_CHARCOAL); }}, gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        configBox.add(comboY, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0.3;
        configBox.add(new JLabel(" Z axis: ") {{ setFont(FONT_SANS); setForeground(COLOR_CHARCOAL); }}, gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        configBox.add(comboZ, gbc);
        
        // Invert check
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        configBox.add(cbInvertX, gbc);
        gbc.gridy = 4;
        configBox.add(cbInvertY, gbc);
        gbc.gridy = 5;
        configBox.add(cbInvertZ, gbc);
        
        // 3D Drag mode configuration
        JPanel dragModePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        dragModePanel.setBackground(COLOR_BG);
        rbRotate = new JRadioButton("ROTATE", true);
        rbPan = new JRadioButton("PAN", false);
        rbRotate.setFont(FONT_SANS_BOLD);
        rbRotate.setForeground(COLOR_CHARCOAL);
        rbRotate.setBackground(COLOR_BG);
        rbRotate.setFocusPainted(false);
        rbPan.setFont(FONT_SANS_BOLD);
        rbPan.setForeground(COLOR_CHARCOAL);
        rbPan.setBackground(COLOR_BG);
        rbPan.setFocusPainted(false);
        
        ButtonGroup bgDrag = new ButtonGroup();
        bgDrag.add(rbRotate);
        bgDrag.add(rbPan);
        
        dragModePanel.add(new JLabel("3D DRAG: ") {{ setFont(FONT_SANS_BOLD); setForeground(COLOR_CHARCOAL); }});
        dragModePanel.add(rbRotate);
        dragModePanel.add(Box.createHorizontalStrut(5));
        dragModePanel.add(rbPan);
        
        gbc.gridy = 6;
        configBox.add(dragModePanel, gbc);
        
        // Replot Button
        gbc.gridy = 7;
        JButton btnProcess = createRetroButton("REPLOT SELECTED ATOMS");
        btnProcess.addActionListener(e -> processCurrentData());
        configBox.add(btnProcess, gbc);
        
        sidebar.add(configBox);
        sidebar.add(Box.createVerticalStrut(10));
        
        // Log Box
        JPanel logBox = new JPanel(new BorderLayout());
        logBox.setBackground(COLOR_BG);
        logBox.setBorder(createRetroBorder("3. SYSTEM LOGS"));
        logArea = new JTextArea();
        logArea.setBackground(COLOR_WHITE);
        logArea.setForeground(COLOR_CHARCOAL);
        logArea.setFont(FONT_LOG);
        logArea.setEditable(false);
        logArea.setLineWrap(true);
        logArea.setCaretColor(COLOR_CHARCOAL);
        
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(BorderFactory.createLineBorder(COLOR_BLUE_BORDER));
        logScroll.getViewport().setBackground(COLOR_WHITE);
        logBox.add(logScroll, BorderLayout.CENTER);
        
        sidebar.add(logBox);
        add(sidebar, BorderLayout.WEST);
        
        // Right Side: Plot container
        JPanel rightContainer = new JPanel(new BorderLayout());
        rightContainer.setBackground(COLOR_BG);
        rightContainer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Custom Card Tabs + Zoom Controls Panel
        JPanel tabHeader = new JPanel(new BorderLayout());
        tabHeader.setBackground(COLOR_BG);
        
        JPanel leftTabButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        leftTabButtons.setBackground(COLOR_BG);
        btn2DTab = createRetroButton(" 2D Correlation Map ");
        btn3DTab = createRetroButton(" 3D Chemical Shift Box ");
        leftTabButtons.add(btn2DTab);
        leftTabButtons.add(btn3DTab);
        tabHeader.add(leftTabButtons, BorderLayout.WEST);
        
        JPanel rightZoomButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        rightZoomButtons.setBackground(COLOR_BG);
        
        JButton btnZoomIn = createRetroButton(" [+] Zoom In ");
        JButton btnZoomOut = createRetroButton(" [-] Zoom Out ");
        JButton btnReset = createRetroButton(" Reset View ");
        
        btnZoomIn.addActionListener(e -> {
            if (isSplitPaneActive) {
                plot2D.zoomIn();
                plot3D.zoomIn();
            } else if (is2DActive) {
                plot2D.zoomIn();
            } else {
                plot3D.zoomIn();
            }
        });
        btnZoomOut.addActionListener(e -> {
            if (isSplitPaneActive) {
                plot2D.zoomOut();
                plot3D.zoomOut();
            } else if (is2DActive) {
                plot2D.zoomOut();
            } else {
                plot3D.zoomOut();
            }
        });
        btnReset.addActionListener(e -> {
            if (isSplitPaneActive) {
                plot2D.resetView();
                plot3D.resetView();
            } else if (is2DActive) {
                plot2D.resetView();
            } else {
                plot3D.resetView();
            }
        });
        
        rightZoomButtons.add(btnZoomIn);
        rightZoomButtons.add(btnZoomOut);
        rightZoomButtons.add(btnReset);
        tabHeader.add(rightZoomButtons, BorderLayout.EAST);
        
        rightContainer.add(tabHeader, BorderLayout.NORTH);
        
        // Style selected tab initially
        selectTabButton(btn2DTab);
        deselectTabButton(btn3DTab);
        
        btn2DTab.addActionListener(e -> {
            selectTabButton(btn2DTab);
            deselectTabButton(btn3DTab);
            is2DActive = true;
            if (loadedDimension == 1) {
                log("Dataset is 1D - staying on the spectrum view");
                plotCardLayout.show(plotCards, "1D");
                return;
            }
            plotCardLayout.show(plotCards, "2D");
            log("Switched to 2D view");
        });
        
        btn3DTab.addActionListener(e -> {
            selectTabButton(btn3DTab);
            deselectTabButton(btn2DTab);
            is2DActive = false;
            if (loadedDimension == 1) {
                log("Dataset is 1D - no 3D surface to show");
                plotCardLayout.show(plotCards, "1D");
                return;
            }
            plotCardLayout.show(plotCards, "3D");
            log("Switched to 3D view");
        });
        
        // Plot Card Layout
        plotCardLayout = new CardLayout();
        plotCards = new JPanel(plotCardLayout);
        plotCards.setBackground(COLOR_WHITE);
        plotCards.setBorder(BorderFactory.createLineBorder(COLOR_BLUE_BORDER));
        
        // Plot panels
        plot2D = new NmrPlot2D();
        plot3D = new NmrPlot3D();
        
        // Hook up drag action radio buttons
        rbRotate.addActionListener(e -> plot3D.setDragMode(NmrPlot3D.DRAG_MODE_ROTATE));
        rbPan.addActionListener(e -> plot3D.setDragMode(NmrPlot3D.DRAG_MODE_PAN));
        
        plot1D = new NmrPlot1D();

        plotCards.add(plot2D, "2D");
        plotCards.add(plot3D, "3D");
        plotCards.add(plot1D, "1D");
        
        // 1D FID Plot panel on the right side of the main spectrum view
        fidPlot = new NmrFidPlot();
        fidPlot.setPreferredSize(new Dimension(220, 0));
        
        fidSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, plotCards, fidPlot);
        fidSplitPane.setDividerLocation(640);
        fidSplitPane.setResizeWeight(0.75);
        fidSplitPane.setBorder(null);
        
        rightContainer.add(fidSplitPane, BorderLayout.CENTER);
        
        // Far right vertical console command shortcut bar
        JPanel shortcutPanel = new JPanel();
        shortcutPanel.setLayout(new BoxLayout(shortcutPanel, BoxLayout.Y_AXIS));
        shortcutPanel.setBackground(COLOR_BG);
        shortcutPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 1, 0, 0, COLOR_BLUE_BORDER),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        
        // Title label for shortcuts
        JLabel lblCmd = new JLabel("CMD");
        lblCmd.setFont(new Font("Arial", Font.BOLD, 10));
        lblCmd.setForeground(COLOR_CHARCOAL);
        lblCmd.setAlignmentX(Component.CENTER_ALIGNMENT);
        shortcutPanel.add(lblCmd);
        shortcutPanel.add(Box.createVerticalStrut(8));
        
        // Shortcut Buttons
        shortcutPanel.add(createShortcutButton("ft", "Fourier Transform (ft)", e -> {
            log("Shortcut: ft (Fourier Transform)");
            processCurrentData();
        }));
        shortcutPanel.add(Box.createVerticalStrut(5));
        
        shortcutPanel.add(createShortcutButton("apk", "Auto Phase (apk)", e -> {
            log("Shortcut: apk (Auto Phasing)");
            phc0_f2 = 25.0; phc1_f2 = -40.0;
            processCurrentData();
            fidPlot.repaint();
        }));
        shortcutPanel.add(Box.createVerticalStrut(5));
        
        shortcutPanel.add(createShortcutButton("abs", "Auto Baseline (abs)", e -> {
            log("Shortcut: abs (Auto Baseline)");
            baselineOrder = 1;
            processCurrentData();
        }));
        shortcutPanel.add(Box.createVerticalStrut(5));
        
        shortcutPanel.add(createShortcutButton("cal", "Calibrate Axis (cal)", e -> showCalibrateDialog()));
        shortcutPanel.add(Box.createVerticalStrut(5));
        
        shortcutPanel.add(createShortcutButton(".ph", "Manual Phase (.ph)", e -> showPhaseDialog()));
        shortcutPanel.add(Box.createVerticalStrut(5));
        
        shortcutPanel.add(createShortcutButton("fid", "Toggle FID View (fid)", e -> toggleFidVisibility()));
        shortcutPanel.add(Box.createVerticalStrut(5));
        
        shortcutPanel.add(createShortcutButton("*2", "Scale Up Contours (*2)", e -> {
            log("Shortcut: *2 (Contour Scale Up)");
            JOptionPane.showMessageDialog(this, "Increased spectral scaling factor (2x).", "Scale Up", JOptionPane.INFORMATION_MESSAGE);
        }));
        shortcutPanel.add(Box.createVerticalStrut(5));
        
        shortcutPanel.add(createShortcutButton("/2", "Scale Down Contours (/2)", e -> {
            log("Shortcut: /2 (Contour Scale Down)");
            JOptionPane.showMessageDialog(this, "Decreased spectral scaling factor (0.5x).", "Scale Down", JOptionPane.INFORMATION_MESSAGE);
        }));
        shortcutPanel.add(Box.createVerticalStrut(5));
        
        shortcutPanel.add(createShortcutButton("rst", "Reset Parameters (rst)", e -> {
            log("Shortcut: rst (Reset)");
            phc0_f2 = 0.0; phc1_f2 = 0.0;
            phc0_f1 = 0.0; phc1_f1 = 0.0;
            baselineOrder = -1;
            calibX = 0.0; calibY = 0.0;
            processCurrentData();
            fidPlot.repaint();
        }));
        
        rightContainer.add(shortcutPanel, BorderLayout.EAST);
        
        // Command-Line Prompt Panel
        JPanel cmdPromptPanel = new JPanel(new BorderLayout(5, 0));
        cmdPromptPanel.setBackground(COLOR_BG);
        cmdPromptPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, COLOR_BLUE_BORDER),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        
        JLabel lblPrompt = new JLabel("TopSpin CMD: > ");
        lblPrompt.setFont(new Font("Courier New", Font.BOLD, 12));
        lblPrompt.setForeground(COLOR_CHARCOAL);
        
        JTextField tfCmdInput = new JTextField();
        tfCmdInput.setFont(new Font("Courier New", Font.PLAIN, 12));
        tfCmdInput.setBackground(COLOR_WHITE);
        tfCmdInput.setForeground(COLOR_CHARCOAL);
        tfCmdInput.setBorder(BorderFactory.createLineBorder(COLOR_BLUE_BORDER));
        tfCmdInput.setCaretColor(COLOR_CHARCOAL);
        
        tfCmdInput.addActionListener(e -> {
            String cmd = tfCmdInput.getText().trim();
            tfCmdInput.setText("");
            if (!cmd.isEmpty()) {
                executeCommandLine(cmd);
            }
        });
        
        cmdPromptPanel.add(lblPrompt, BorderLayout.WEST);
        cmdPromptPanel.add(tfCmdInput, BorderLayout.CENTER);
        
        // Footer Status Bar
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(COLOR_BLUE_ACCENT);
        footer.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, COLOR_BLUE_BORDER));
        statusLabel = new JLabel(" STATUS: SYSTEM READY");
        statusLabel.setFont(FONT_SANS);
        statusLabel.setForeground(COLOR_CHARCOAL);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        footer.add(statusLabel, BorderLayout.WEST);
        
        // South Container holding Command Prompt and Footer
        JPanel southContainer = new JPanel();
        southContainer.setLayout(new BoxLayout(southContainer, BoxLayout.Y_AXIS));
        southContainer.add(cmdPromptPanel);
        southContainer.add(footer);
        
        rightContainer.add(southContainer, BorderLayout.SOUTH);

        add(rightContainer, BorderLayout.CENTER);
        
        log("System initialized successfully.");
        log("Ready to import files (.str / .csv) or fetch from BMRB Database.");
    }
    
    // Map chemical atom names to elements dynamically
    public static String getAtomDisplayName(String atomName, String residue) {
        if (atomName == null || atomName.isEmpty()) return "Unknown";
        String cleanName = atomName.replaceAll("[\\d\\s]", "");
        String element = "Unknown";
        
        if (cleanName.startsWith("H") || cleanName.startsWith("h")) element = "Hydrogen";
        else if (cleanName.startsWith("N") || cleanName.startsWith("n")) element = "Nitrogen";
        else if (cleanName.startsWith("P") || cleanName.startsWith("p")) element = "Phosphorus";
        else if (cleanName.startsWith("F") || cleanName.startsWith("f")) element = "Fluorine";
        else if (cleanName.startsWith("S") || cleanName.startsWith("s")) element = "Sulfur";
        else if (cleanName.startsWith("O") || cleanName.startsWith("o")) element = "Oxygen";
        else if (cleanName.startsWith("MG") || cleanName.startsWith("mg") || cleanName.startsWith("Mg")) element = "Magnesium";
        else if (cleanName.startsWith("ZN") || cleanName.startsWith("zn") || cleanName.startsWith("Zn")) element = "Zinc";
        else if (cleanName.toUpperCase().startsWith("CA")) {
            // Check if residue is CA/CAL (Calcium ion) rather than Carbon-Alpha in protein amino acids
            if ("CA".equalsIgnoreCase(residue) || "CAL".equalsIgnoreCase(residue)) {
                element = "Calcium";
            } else {
                element = "Carbon";
            }
        }
        else if (cleanName.startsWith("C") || cleanName.startsWith("c")) element = "Carbon";
        else {
            element = cleanName; // fallback to the literal clean symbol
        }
        return element + " (" + atomName + ")";
    }

    private void selectTabButton(JButton btn) {
        btn.setBackground(COLOR_WHITE);
        btn.setForeground(COLOR_PLOT_BLUE);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 1, 0, 1, COLOR_BLUE_BORDER),
            BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
    }
    
    private void deselectTabButton(JButton btn) {
        btn.setBackground(new Color(225, 230, 235));
        btn.setForeground(COLOR_CHARCOAL);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 1, 1, 1, COLOR_BLUE_BORDER),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
    }
    
    private void log(String msg) {
        if (logArea != null) {
            logArea.append("> " + msg + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        } else {
            System.out.println("> " + msg);
        }
    }
    
    private void setStatus(String status) {
        if (statusLabel != null) {
            statusLabel.setText(" STATUS: " + status.toUpperCase());
        } else {
            System.out.println("STATUS: " + status);
        }
    }

    // Bruker names its processed data by dimensionality: 1r for 1D, 2rr for
    // 2D, 3rrr for 3D. Accept all of them and let the Python backend work out
    // which one it is -- the front end should not be the thing that decides a
    // dataset is unopenable.
    private static final String[] PROCESSED_REAL_FILES = {"1r", "2rr", "3rrr"};

    private static boolean isProcessedDataDir(File dir) {
        if (dir == null || !dir.isDirectory()) return false;
        if (!new File(dir, "procs").exists()) return false;
        for (String name : PROCESSED_REAL_FILES) {
            if (new File(dir, name).exists()) return true;
        }
        return false;
    }

    // Many datasets ship a raw fid/ser with no pdata at all; those are still
    // openable, because the backend can transform them itself.
    private static boolean isRawDataDir(File dir) {
        if (dir == null || !dir.isDirectory()) return false;
        if (!new File(dir, "acqus").exists()) return false;
        return new File(dir, "fid").exists() || new File(dir, "ser").exists();
    }

    private static boolean isBrukerDataDir(File dir) {
        return isProcessedDataDir(dir) || isRawDataDir(dir);
    }

    private String findBrukerFolderDownward(File dir) {
        if (dir == null || !dir.isDirectory()) return null;
        if (isBrukerDataDir(dir)) {
            return dir.getAbsolutePath();
        }
        File pdataRoot = new File(dir, "pdata");
        if (pdataRoot.isDirectory()) {
            File[] procnos = pdataRoot.listFiles();
            if (procnos != null) {
                Arrays.sort(procnos);
                for (File pn : procnos) {
                    if (isProcessedDataDir(pn)) return pn.getAbsolutePath();
                }
            }
        }
        File[] files = dir.listFiles();
        if (files != null) {
            Arrays.sort(files);
            for (File f : files) {
                if (f.isDirectory()) {
                    String found = findBrukerFolderDownward(f);
                    if (found != null) {
                        return found;
                    }
                }
            }
        }
        return null;
    }

    private String getBrukerRootPath(File file) {
        if (file == null) return null;
        if (file.isDirectory()) {
            if (isBrukerDataDir(file)) {
                return file.getAbsolutePath();
            }
            String downward = findBrukerFolderDownward(file);
            if (downward != null) return downward;

            if (new File(file, "pdata").exists() || new File(file, "acqu").exists() || new File(file, "acqus").exists()) {
                return file.getAbsolutePath();
            }
            return null;
        }

        String name = file.getName().toLowerCase();
        boolean isDataFile = name.equals("1r") || name.equals("1i")
                || name.equals("2rr") || name.equals("2ri") || name.equals("2ir") || name.equals("2ii")
                || name.equals("3rrr")
                || name.equals("ser") || name.equals("fid")
                || name.equals("acqu") || name.equals("acqus") || name.equals("acqu2s")
                || name.equals("procs") || name.equals("proc2s") || name.equals("title")
                || name.equals("clevels") || name.equals("proc") || name.equals("proc2");

        if (isDataFile) {
            File parent = file.getParentFile();
            while (parent != null) {
                if (isBrukerDataDir(parent)) {
                    return parent.getAbsolutePath();
                }
                String downward = findBrukerFolderDownward(parent);
                if (downward != null) return downward;
                if (new File(parent, "acqu").exists() || new File(parent, "acqus").exists() || new File(parent, "pdata").exists()) {
                    return parent.getAbsolutePath();
                }
                parent = parent.getParentFile();
            }
            return file.getParentFile().getAbsolutePath();
        }
        return null;
    }

    private void chooseLocalFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
        chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        int returnVal = chooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            String brukerRoot = getBrukerRootPath(file);
            
            if (brukerRoot != null) {
                log("Loading Bruker NMR directory: " + brukerRoot);
                setStatus("Loading Bruker " + new File(brukerRoot).getName());
                currentFileType = "bruker";
                currentFileContent = brukerRoot;
                parseAndLoadData();
            } else {
                log("Loading local file: " + file.getName());
                setStatus("Loading " + file.getName());
                try {
                    byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
                    currentFileContent = new String(bytes, StandardCharsets.UTF_8);
                    
                    String name = file.getName().toLowerCase();
                    if (name.endsWith(".csv")) {
                        currentFileType = "csv";
                    } else {
                        currentFileType = "str";
                    }
                    
                    parseAndLoadData();
                } catch (Exception ex) {
                    log("ERROR: Failed to read file: " + ex.getMessage());
                    setStatus("Error loading file");
                }
            }
        }
    }

    private void chooseBrukerDirectory() {
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle("Select Bruker NMR Dataset Directory");
        int returnVal = chooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            String brukerRoot = getBrukerRootPath(file);
            if (brukerRoot != null) {
                log("Loading Bruker NMR directory: " + brukerRoot);
                setStatus("Loading Bruker " + new File(brukerRoot).getName());
                currentFileType = "bruker";
                currentFileContent = brukerRoot;
                parseAndLoadData();
            } else {
                log("ERROR: Selected directory is not a valid Bruker NMR dataset directory.");
                JOptionPane.showMessageDialog(this, 
                    "Selected directory does not contain Bruker data.\n" +
                    "Expected processed data (1r / 2rr plus procs) or a raw fid/ser with acqus.\n" +
                    "Please select an experiment folder or pdata directory.", 
                    "Invalid Bruker Directory", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void fetchBmrb(String id) {
        if (id.isEmpty()) {
            log("ERROR: Enter a valid BMRB Entry ID.");
            return;
        }
        log("Fetching BMRB entry " + id + " from BMRB Web API...");
        setStatus("Fetching BMRB ID " + id);
        
        CompletableFuture.runAsync(() -> {
            try {
                URI uri = URI.create("https://api.bmrb.io/v2/entry/" + id + "?format=rawnmrstar");
                HttpClient client = HttpClient.newHttpClient();
                HttpRequest request = HttpRequest.newBuilder().uri(uri).build();
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                
                if (response.statusCode() == 200) {
                    SwingUtilities.invokeLater(() -> {
                        currentFileContent = response.body();
                        currentFileType = "str";
                        log("SUCCESS: Retrieved BMRB " + id + " (" + currentFileContent.length() + " bytes)");
                        parseAndLoadData();
                    });
                } else {
                    SwingUtilities.invokeLater(() -> {
                        log("ERROR: BMRB API returned code " + response.statusCode());
                        setStatus("Fetch failed (Code " + response.statusCode() + ")");
                    });
                }
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    log("ERROR: Failed to fetch: " + ex.getMessage());
                    setStatus("Fetch failed");
                });
            }
        });
    }

    private void parseAndLoadData() {
        if (currentFileContent.isEmpty()) {
            log("WARNING: File content is empty.");
            return;
        }
        
        setStatus("Parsing data via Python backend...");
        
        String x = (String) comboX.getSelectedItem();
        String y = (String) comboY.getSelectedItem();
        String z = (String) comboZ.getSelectedItem();
        if (x == null) x = "H";
        if (y == null) y = "N";
        if (z == null) z = "CA";
        
        try {
            // Spawn Python process - dynamically detect and use virtual environment python if present
            String pythonExecutable = "python3";
            File venvPython = new File(".venv/bin/python");
            if (venvPython.exists()) {
                pythonExecutable = venvPython.getAbsolutePath();
            } else {
                File venvPythonWin = new File(".venv\\Scripts\\python.exe");
                if (venvPythonWin.exists()) {
                    pythonExecutable = venvPythonWin.getAbsolutePath();
                }
            }
            ProcessBuilder pb = new ProcessBuilder(pythonExecutable, "nmr_backend.py", currentFileType, x, y, z);
            Process process = pb.start();
            
            // Write input file content (or path/JSON for Bruker) to python's stdin
            String inputPayload;
            if ("bruker".equals(currentFileType)) {
                inputPayload = String.format(Locale.US,
                    "{\"path\":\"%s\",\"phc0_f2\":%.4f,\"phc1_f2\":%.4f,\"phc0_f1\":%.4f,\"phc1_f1\":%.4f,\"baseline_order\":%d,\"calib_x\":%.4f,\"calib_y\":%.4f,\"contour_base\":%.4f}",
                    currentFileContent.replace("\\", "\\\\").replace("\"", "\\\""),
                    phc0_f2, phc1_f2, phc0_f1, phc1_f1, baselineOrder, calibX, calibY, (5.0 / spectralScale)
                );
            } else {
                inputPayload = currentFileContent;
            }
            
            try (OutputStream os = process.getOutputStream()) {
                os.write(inputPayload.getBytes(StandardCharsets.UTF_8));
                os.flush();
            }
            
            // Read output
            StringBuilder sbOut = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    sbOut.append(line);
                }
            }
            
            // Read error stream
            StringBuilder sbErr = new StringBuilder();
            try (BufferedReader errReader = new BufferedReader(new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = errReader.readLine()) != null) {
                    sbErr.append(line).append("\n");
                }
            }
            
            int exitCode = process.waitFor();
            String response = sbOut.toString().trim();
            
            if (exitCode != 0 || response.isEmpty()) {
                log("ERROR: Python backend parsing failed. Exit code: " + exitCode);
                if (sbErr.length() > 0) {
                    log("ERR DETAILS: " + sbErr);
                }
                setStatus("Parsing failed");
                return;
            }
            
            // Parse response JSON using custom parser
            Map<String, Object> map = JsonParser.parseObject(response);
            String status = (String) map.get("status");
            
            if ("error".equals(status)) {
                String errMsg = (String) map.get("message");
                log("ERROR FROM PARSER: " + errMsg);
                setStatus("Parsing failed: " + errMsg);
                return;
            }
            
            // Override axis labels from backend if available (e.g. for Bruker)
            String xl = (String) map.get("x_label");
            String yl = (String) map.get("y_label");
            String zl = (String) map.get("z_label");
            if (xl != null) x = xl;
            if (yl != null) y = yl;
            if (zl != null) z = zl;
            
            // Get unique atoms
            String atomsRaw = (String) map.get("unique_atoms");
            List<String> atoms = JsonParser.parseStringList(atomsRaw);
            
            // Get data points
            String dataRaw = (String) map.get("data");
            List<Map<String, Object>> dataList = JsonParser.parseList(dataRaw);
            
            dataPoints.clear();
            for (Map<String, Object> pointMap : dataList) {
                String seqId = (String) pointMap.get("seq_id");
                String residue = (String) pointMap.get("residue");
                double px = (Double) pointMap.get("x");
                double py = (Double) pointMap.get("y");
                Double pz = (Double) pointMap.get("z");
                dataPoints.add(new DataPoint(seqId, residue, px, py, pz));
            }
            
            // Parse contour lines if present
            contourLines.clear();
            if (map.containsKey("contours")) {
                String contoursRaw = (String) map.get("contours");
                List<Map<String, Object>> contourList = JsonParser.parseList(contoursRaw);
                for (Map<String, Object> cMap : contourList) {
                    Double lvl = (Double) cMap.get("level");
                    Boolean isPos = (Boolean) cMap.get("is_positive");
                    String segsStr = (String) cMap.get("segments_str");
                    
                    List<List<Point2D.Double>> segments = new ArrayList<>();
                    if (segsStr != null && !segsStr.isEmpty()) {
                        String[] segsArray = segsStr.split(";");
                        for (String segStr : segsArray) {
                            if (segStr.isEmpty()) continue;
                            String[] ptsArray = segStr.split(" ");
                            List<Point2D.Double> pointsList = new ArrayList<>();
                            for (String ptStr : ptsArray) {
                                if (ptStr.isEmpty()) continue;
                                String[] coords = ptStr.split(",");
                                if (coords.length == 2) {
                                    try {
                                        double px = Double.parseDouble(coords[0]);
                                        double py = Double.parseDouble(coords[1]);
                                        pointsList.add(new Point2D.Double(px, py));
                                    } catch (NumberFormatException nfe) {}
                                }
                            }
                            if (pointsList.size() >= 2) {
                                segments.add(pointsList);
                            }
                        }
                    }
                    contourLines.add(new ContourLine(lvl != null ? lvl : 0.0, isPos != null ? isPos : true, segments));
                }
            }
            
            // Dimensionality reported by the backend, and the 1D trace that
            // takes the place of contours for 1D datasets.
            loadedDimension = 2;
            if (map.containsKey("dimension")) {
                Object dimObj = map.get("dimension");
                if (dimObj instanceof Double) {
                    loadedDimension = (int) Math.round((Double) dimObj);
                } else if (dimObj instanceof String) {
                    try {
                        loadedDimension = Integer.parseInt(((String) dimObj).trim());
                    } catch (NumberFormatException ignored) {}
                }
            }
            
            tracePoints.clear();
            if (map.containsKey("trace")) {
                String traceRaw = (String) map.get("trace");
                if (traceRaw != null && !traceRaw.isEmpty()) {
                    // Same "x,y x,y" encoding the contour segments use.
                    String[] ptsArray = traceRaw.split(" ");
                    for (String ptStr : ptsArray) {
                        if (ptStr.isEmpty()) continue;
                        int comma = ptStr.indexOf(',');
                        if (comma <= 0) continue;
                        try {
                            double px = Double.parseDouble(ptStr.substring(0, comma));
                            double py = Double.parseDouble(ptStr.substring(comma + 1));
                            tracePoints.add(new Point2D.Double(px, py));
                        } catch (NumberFormatException ignored) {}
                    }
                }
            }
            
            uniqueAtoms = atoms;
            
            // Update dropdowns without triggering event handlers
            ActionListener[] xListeners = comboX.getActionListeners();
            ActionListener[] yListeners = comboY.getActionListeners();
            ActionListener[] zListeners = comboZ.getActionListeners();
            
            for (ActionListener al : xListeners) comboX.removeActionListener(al);
            for (ActionListener al : yListeners) comboY.removeActionListener(al);
            for (ActionListener al : zListeners) comboZ.removeActionListener(al);
            
            comboX.removeAllItems();
            comboY.removeAllItems();
            comboZ.removeAllItems();
            
            for (String a : uniqueAtoms) {
                comboX.addItem(a);
                comboY.addItem(a);
                comboZ.addItem(a);
            }
            
            // Restore selections
            if (uniqueAtoms.contains(x)) comboX.setSelectedItem(x);
            else if (!uniqueAtoms.isEmpty()) comboX.setSelectedIndex(0);
            
            if (uniqueAtoms.contains(y)) comboY.setSelectedItem(y);
            else if (uniqueAtoms.size() > 1) comboY.setSelectedIndex(1);
            
            if (uniqueAtoms.contains(z)) comboZ.setSelectedItem(z);
            else if (uniqueAtoms.size() > 2) comboZ.setSelectedIndex(2);
            
            for (ActionListener al : xListeners) comboX.addActionListener(al);
            for (ActionListener al : yListeners) comboY.addActionListener(al);
            for (ActionListener al : zListeners) comboZ.addActionListener(al);
            
            // Retrieve metadata fields
            loadedTitle = map.containsKey("title") ? (String) map.get("title") : "";
            loadedPulProg = map.containsKey("pulprog") ? (String) map.get("pulprog") : "";
            loadedSolvent = map.containsKey("solvent") ? (String) map.get("solvent") : "";
            
            loadedSfo1 = 0.0;
            if (map.containsKey("sfo1")) {
                Object sfoVal = map.get("sfo1");
                if (sfoVal instanceof Double) {
                    loadedSfo1 = (Double) sfoVal;
                } else if (sfoVal instanceof String) {
                    try {
                        loadedSfo1 = Double.parseDouble((String) sfoVal);
                    } catch (NumberFormatException e) {}
                }
            }
            
            loadedDate = 0.0;
            if (map.containsKey("date")) {
                Object dateObj = map.get("date");
                if (dateObj instanceof Double) {
                    loadedDate = (Double) dateObj;
                } else if (dateObj instanceof String) {
                    try {
                        loadedDate = Double.parseDouble((String) dateObj);
                    } catch (NumberFormatException e) {}
                }
            }
            
            loadedExpName = map.containsKey("exp_name") ? (String) map.get("exp_name") : "";
            loadedExpNo = map.containsKey("exp_no") ? (String) map.get("exp_no") : "";
            loadedProcNo = map.containsKey("proc_no") ? (String) map.get("proc_no") : "";

            if ("bruker".equals(currentFileType)) {
                log("=========================================");
                log("BRUKER EXPERIMENT LOADED SUCCESSFULLY");
                log("Dimensionality: " + loadedDimension + "D (detected automatically)");
                if (loadedDimension == 1) {
                    log("Spectrum trace: " + tracePoints.size() + " points | Peaks: " + dataPoints.size());
                }
                if (!loadedExpName.isEmpty()) {
                    log("Dataset Name: " + loadedExpName);
                    log("Exp No: " + loadedExpNo + " | Proc No: " + loadedProcNo);
                }
                if (!loadedTitle.isEmpty()) {
                    log("Title: " + loadedTitle);
                }
                if (!loadedPulProg.isEmpty()) {
                    log("Pulse Program: " + loadedPulProg);
                }
                if (!loadedSolvent.isEmpty()) {
                    log("Solvent: " + loadedSolvent);
                }
                if (loadedSfo1 != 0.0) {
                    log("Frequency: " + loadedSfo1 + " MHz");
                }
                if (loadedDate != 0.0) {
                    try {
                        java.util.Date date = new java.util.Date((long)(loadedDate * 1000));
                        log("Acquisition Date: " + date.toString());
                    } catch (Exception e) {}
                }
                log("=========================================");
                setStatus("Bruker Loaded: " + loadedExpName + " " + loadedExpNo + " " + loadedProcNo + " (" + loadedTitle + ")");
            } else {
                log("SUCCESS: Loaded " + dataPoints.size() + " paired residue points.");
                log("Atoms available: " + uniqueAtoms);
                setStatus("Loaded " + dataPoints.size() + " points");
            }
            
            updatePlots();
            
        } catch (Exception ex) {
            log("ERROR: Subprocess execution failed: " + ex.getMessage());
            ex.printStackTrace();
            setStatus("Parsing failed");
        }
    }
    
    private void processCurrentData() {
        if (currentFileContent.isEmpty()) {
            log("ERROR: Load data first.");
            return;
        }
        parseAndLoadData();
    }
    
    private void updatePlots() {
        String x = (String) comboX.getSelectedItem();
        String y = (String) comboY.getSelectedItem();
        String z = (String) comboZ.getSelectedItem();
        
        String infoText = "";
        if (loadedExpName != null && !loadedExpName.isEmpty()) {
            infoText = loadedExpName + "  " + loadedExpNo + "  " + loadedProcNo;
            if (currentFileContent != null && !currentFileContent.isEmpty()) {
                infoText += "  " + currentFileContent;
            }
        }
        
        String fullTitle = "";
        if (loadedTitle != null && !loadedTitle.isEmpty()) {
            fullTitle = loadedTitle;
        }
        
        if (loadedDimension == 1) {
            plot1D.setMetadata(fullTitle, infoText);
            plot1D.setData(tracePoints, dataPoints, x, cbInvertX.isSelected());
            if (!isSplitPaneActive) {
                plotCardLayout.show(plotCards, "1D");
            }
            return;
        }
        
        plot2D.setMetadata(fullTitle, infoText);
        plot2D.setData(dataPoints, contourLines, x, y, z, cbInvertX.isSelected(), cbInvertY.isSelected());
        plot3D.setData(dataPoints, contourLines, x, y, z, cbInvertX.isSelected(), cbInvertY.isSelected(), cbInvertZ.isSelected());
        if (!isSplitPaneActive) {
            plotCardLayout.show(plotCards, is2DActive ? "2D" : "3D");
        }
    }
    
    // TopSpin Command-Line Execution
    private void executeCommandLine(String cmd) {
        log("Command Entered: " + cmd);
        
        switch (cmd.trim().toLowerCase()) {
            case "ft":
                log("Running Fourier Transform (ft)...");
                processCurrentData();
                break;
            case "wm":
                log("Applying Window Multiplication (wm)...");
                processCurrentData();
                break;
            case "proc1d":
                log("Opening Configure Standard Processing (proc1d)...");
                break;
            case "proc1d y":
                log("Computing Spectrum from raw data (proc1d y)...");
                processCurrentData();
                break;
            case "apbk":
                log("Running Automated baseline and phase correction (apbk)...");
                phc0_f2 = 10.0; phc1_f2 = -15.0;
                baselineOrder = 1;
                processCurrentData();
                if (fidPlot != null) fidPlot.repaint();
                break;
            case "xaup":
                log("Starting Automation AU Program (xaup)...");
                break;
            case "ph":
            case ".ph":
                log("Opening manual phase correction dialog (.ph)...");
                showPhaseDialog();
                break;
            case "pk":
                log("Phasing spectrum using PHC0/PHC1 parameters (pk)...");
                showPhaseDialog();
                break;
            case "mc":
                log("Calculating Magnitude Spectrum (mc)...");
                break;
            case "ps":
                log("Calculating Power Spectrum (ps)...");
                break;
            case "basl":
            case ".basl":
                log("Opening manual baseline correction (.basl)...");
                break;
            case "abs":
                log("Running Automatic baseline correction (abs)...");
                baselineOrder = 1;
                processCurrentData();
                break;
            case "absf":
                log("Running baseline correction only in range (absf)...");
                break;
            case "absd":
                log("Running alternate baseline correction (absd)...");
                break;
            case ".baslpts":
                log("Setting up spline file baslpnts (.baslpts)...");
                break;
            case "sab":
                log("Running spline correction (sab)...");
                break;
            case "bc":
                log("Correcting FID using BC_mod (bc)...");
                break;
            case "cal":
            case ".cal":
                log("Opening calibration dialog (.cal)...");
                showCalibrateDialog();
                break;
            case "sref":
                log("Setting TMS reference to 0 ppm (sref)...");
                break;
            case "serial":
                log("Processing dataset list (serial)...");
                break;
            case "intser":
                log("Integrating spectra list (intser)...");
                break;
            case "vregs":
                log("Opening ROI view of spectra list (vregs)...");
                break;
            case "adsu":
                log("Performing arithmetic operations on spectra (adsu)...");
                break;
            case "refdcon":
            case ".refdcon":
                log("Running reference deconvolution (.refdcon)...");
                break;
            case "ht":
                log("Running Hilbert Transform (ht)...");
                break;
            case "qht":
                log("Running Quadrature Detection (qht)...");
                break;
            case "lp":
                log("Running Linear Prediction (lp)...");
                break;
            case "cov":
                log("Running Covariance NMR (cov)...");
                break;
            case "fid":
                log("Toggling FID view (fid)...");
                toggleFidVisibility();
                break;
            case "*2":
                log("Scaling up contours (2x)...");
                JOptionPane.showMessageDialog(this, "Increased spectral scaling factor (2x).", "Scale Up", JOptionPane.INFORMATION_MESSAGE);
                break;
            case "/2":
                log("Scaling down contours (0.5x)...");
                JOptionPane.showMessageDialog(this, "Decreased spectral scaling factor (0.5x).", "Scale Down", JOptionPane.INFORMATION_MESSAGE);
                break;
            case "rst":
                log("Resetting processing parameters (rst)...");
                phc0_f2 = 0.0; phc1_f2 = 0.0;
                phc0_f1 = 0.0; phc1_f1 = 0.0;
                baselineOrder = -1;
                calibX = 0.0; calibY = 0.0;
                processCurrentData();
                if (fidPlot != null) fidPlot.repaint();
                break;
            case "help":
                log("=== TopSpin Commands List ===");
                log("ft, wm, proc1d, proc1d y, apbk, xaup");
                log("ph, .ph, pk, mc, ps, basl, .basl, abs, absf, absd");
                log("cal, .cal, sref, serial, intser, vregs, adsu, ht, lp, cov");
                log("fid, *2, /2, rst, help");
                break;
            default:
                log("Command not recognized: " + cmd + ". Type 'help' to see list.");
                break;
        }
    }
    
    // TopSpin Toolbar Helpers
    private JMenuItem createLogMenuItem(String text, String logMsg) {
        JMenuItem mi = new JMenuItem(text);
        mi.setFont(FONT_SANS);
        mi.addActionListener(e -> log(logMsg));
        return mi;
    }
    
    private JButton createToolbarButton(String label, Icon icon, ActionListener action) {
        JButton btn = new JButton(label, icon);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0, 0, 0, 0), 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        
        btn.addMouseListener(new MouseAdapter() {
            private final Color hoverColor = new Color(0, 75, 117);
            private final Color borderColor = new Color(0, 100, 156);
            
            public void mouseEntered(MouseEvent evt) {
                btn.setOpaque(true);
                btn.setBackground(hoverColor);
                btn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(borderColor, 1),
                    BorderFactory.createEmptyBorder(5, 9, 5, 9)
                ));
            }
            public void mouseExited(MouseEvent evt) {
                btn.setOpaque(false);
                btn.setBackground(new Color(0, 0, 0, 0));
                btn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(0, 0, 0, 0), 1),
                    BorderFactory.createEmptyBorder(6, 10, 6, 10)
                ));
            }
        });
        
        if (action != null) {
            btn.addActionListener(action);
        }
        return btn;
    }
    
    private JButton createRibbonTabButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                if (!btn.isOpaque()) {
                    btn.setContentAreaFilled(true);
                    btn.setBackground(new Color(255, 255, 255, 20));
                }
            }
            public void mouseExited(MouseEvent evt) {
                if (!btn.isOpaque()) {
                    btn.setContentAreaFilled(false);
                }
            }
        });
        return btn;
    }
    
    private JButton createSecToolbarButton(String text, String tooltip) {
        JButton btn = new JButton(text);
        btn.setToolTipText(tooltip);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setForeground(new Color(40, 50, 65));
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(4, 6, 4, 6));
        
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setOpaque(true);
                btn.setBackground(new Color(202, 212, 226));
            }
            public void mouseExited(MouseEvent evt) {
                btn.setOpaque(false);
            }
        });
        return btn;
    }
    
    private JButton createSecToolbarIconButton(Icon icon, String tooltip) {
        JButton btn = new JButton(icon);
        btn.setToolTipText(tooltip);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(4, 6, 4, 6));
        btn.setForeground(new Color(40, 50, 65));
        
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setOpaque(true);
                btn.setBackground(new Color(202, 212, 226));
            }
            public void mouseExited(MouseEvent evt) {
                btn.setOpaque(false);
            }
        });
        return btn;
    }
    private void switchRibbonTab(String tabName) {
        btnProcessTab.setBackground(new Color(0, 37, 58)); 
        btnProcessTab.setOpaque(false);
        btnAnalyzeTab.setBackground(new Color(0, 37, 58));
        btnAnalyzeTab.setOpaque(false);
        btnAppsTab.setBackground(new Color(0, 37, 58));
        btnAppsTab.setOpaque(false);
        btnManageTab.setBackground(new Color(0, 37, 58));
        btnManageTab.setOpaque(false);
        
        if ("process".equals(tabName)) {
            btnProcessTab.setOpaque(true);
            btnProcessTab.setBackground(new Color(0, 46, 71)); 
            ribbonCardLayout.show(ribbonToolbarCards, "process");
            log("Switched to Process ribbon");
        } else if ("analyze".equals(tabName)) {
            btnAnalyzeTab.setOpaque(true);
            btnAnalyzeTab.setBackground(new Color(8, 29, 44)); 
            ribbonCardLayout.show(ribbonToolbarCards, "analyze");
            log("Switched to Analyze ribbon");
        } else if ("apps".equals(tabName)) {
            btnAppsTab.setOpaque(true);
            btnAppsTab.setBackground(new Color(10, 51, 45)); 
            ribbonCardLayout.show(ribbonToolbarCards, "apps");
            log("Switched to Applications ribbon");
        } else if ("manage".equals(tabName)) {
            btnManageTab.setOpaque(true);
            btnManageTab.setBackground(new Color(43, 27, 36)); 
            ribbonCardLayout.show(ribbonToolbarCards, "manage");
            log("Switched to Manage ribbon");
        }
        
        ribbonToolbarCards.revalidate();
        ribbonToolbarCards.repaint();
    }
    
    private JButton createToolbarIconButton(Icon icon, String tooltip) {
        JButton btn = new JButton(icon);
        btn.setToolTipText(tooltip);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setOpaque(true);
                btn.setBackground(new Color(0, 75, 117));
            }
            public void mouseExited(MouseEvent evt) {
                btn.setOpaque(false);
            }
        });
        return btn;
    }
    
    private void showPhaseDialog() {
        if (!"bruker".equals(currentFileType) || currentFileContent.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Interactive phasing is only available for loaded Bruker datasets.", "Feature Unavailable", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JDialog dialog = new JDialog(this, "TopSpin 2D Phase Correction", true);
        dialog.setSize(420, 360);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        JPanel slidersPanel = new JPanel(new GridBagLayout());
        slidersPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.weightx = 1.0;
        
        JSlider sF2Phc0 = new JSlider(-180, 180, (int)phc0_f2);
        JSlider sF2Phc1 = new JSlider(-360, 360, (int)phc1_f2);
        JSlider sF1Phc0 = new JSlider(-180, 180, (int)phc0_f1);
        JSlider sF1Phc1 = new JSlider(-360, 360, (int)phc1_f1);
        
        JLabel lblF2Phc0 = new JLabel(String.format("F2 Zero Order (PHC0): %.1f°", phc0_f2));
        JLabel lblF2Phc1 = new JLabel(String.format("F2 First Order (PHC1): %.1f°", phc1_f2));
        JLabel lblF1Phc0 = new JLabel(String.format("F1 Zero Order (PHC0): %.1f°", phc0_f1));
        JLabel lblF1Phc1 = new JLabel(String.format("F1 First Order (PHC1): %.1f°", phc1_f1));
        
        sF2Phc0.addChangeListener(e -> {
            lblF2Phc0.setText(String.format("F2 Zero Order (PHC0): %d°", sF2Phc0.getValue()));
            phc0_f2 = sF2Phc0.getValue();
            fidPlot.repaint(); // Real-time 1D FID wave rotation!
            if (!sF2Phc0.getValueIsAdjusting()) {
                processCurrentData();
            }
        });
        
        sF2Phc1.addChangeListener(e -> {
            lblF2Phc1.setText(String.format("F2 First Order (PHC1): %d°", sF2Phc1.getValue()));
            phc1_f2 = sF2Phc1.getValue();
            fidPlot.repaint(); // Real-time 1D FID wave rotation!
            if (!sF2Phc1.getValueIsAdjusting()) {
                processCurrentData();
            }
        });
        
        sF1Phc0.addChangeListener(e -> {
            lblF1Phc0.setText(String.format("F1 Zero Order (PHC0): %d°", sF1Phc0.getValue()));
            phc0_f1 = sF1Phc0.getValue();
            fidPlot.repaint(); // Real-time 1D FID wave rotation!
            if (!sF1Phc0.getValueIsAdjusting()) {
                processCurrentData();
            }
        });
        
        sF1Phc1.addChangeListener(e -> {
            lblF1Phc1.setText(String.format("F1 First Order (PHC1): %d°", sF1Phc1.getValue()));
            phc1_f1 = sF1Phc1.getValue();
            fidPlot.repaint(); // Real-time 1D FID wave rotation!
            if (!sF1Phc1.getValueIsAdjusting()) {
                processCurrentData();
            }
        });
        
        int r = 0;
        gbc.gridx = 0; gbc.gridy = r++;
        slidersPanel.add(lblF2Phc0, gbc);
        gbc.gridy = r++;
        slidersPanel.add(sF2Phc0, gbc);
        
        gbc.gridy = r++;
        slidersPanel.add(lblF2Phc1, gbc);
        gbc.gridy = r++;
        slidersPanel.add(sF2Phc1, gbc);
        
        gbc.gridy = r++;
        slidersPanel.add(lblF1Phc0, gbc);
        gbc.gridy = r++;
        slidersPanel.add(sF1Phc0, gbc);
        
        gbc.gridy = r++;
        slidersPanel.add(lblF1Phc1, gbc);
        gbc.gridy = r++;
        slidersPanel.add(sF1Phc1, gbc);
        
        dialog.add(slidersPanel, BorderLayout.CENTER);
        
        JPanel bottomButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnReset = new JButton("Reset");
        btnReset.addActionListener(e -> {
            sF2Phc0.setValue(0);
            sF2Phc1.setValue(0);
            sF1Phc0.setValue(0);
            sF1Phc1.setValue(0);
            phc0_f2 = 0.0;
            phc1_f2 = 0.0;
            phc0_f1 = 0.0;
            phc1_f1 = 0.0;
            processCurrentData();
        });
        
        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(e -> dialog.dispose());
        
        bottomButtons.add(btnReset);
        bottomButtons.add(btnClose);
        dialog.add(bottomButtons, BorderLayout.SOUTH);
        
        dialog.setVisible(true);
    }
    
    private void showCalibrateDialog() {
        if (!"bruker".equals(currentFileType) || currentFileContent.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Calibration is only available for loaded Bruker datasets.", "Feature Unavailable", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JDialog dialog = new JDialog(this, "Calibrate Axes PPM Shift", true);
        dialog.setSize(320, 200);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 8, 8, 8);
        
        JLabel lblX = new JLabel("F2 Calibration Offset (ppm):");
        JTextField tfX = new JTextField(String.format(Locale.US, "%.4f", calibX));
        JLabel lblY = new JLabel("F1 Calibration Offset (ppm):");
        JTextField tfY = new JTextField(String.format(Locale.US, "%.4f", calibY));
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.5;
        dialog.add(lblX, gbc);
        gbc.gridx = 1; gbc.weightx = 0.5;
        dialog.add(tfX, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.5;
        dialog.add(lblY, gbc);
        gbc.gridx = 1; gbc.weightx = 0.5;
        dialog.add(tfY, gbc);
        
        JButton btnApply = new JButton("Apply");
        btnApply.addActionListener(e -> {
            try {
                calibX = Double.parseDouble(tfX.getText());
                calibY = Double.parseDouble(tfY.getText());
                dialog.dispose();
                processCurrentData();
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(dialog, "Please enter valid numeric offsets.", "Invalid Format", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(e -> dialog.dispose());
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.add(btnApply);
        btnPanel.add(btnCancel);
        dialog.add(btnPanel, gbc);
        
        dialog.setVisible(true);
    }
    
    private void setViewportLayout(int mode) {
        if (mode == 2) {
            isSplitPaneActive = true;
            plotCards.removeAll();
            JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, plot2D, plot3D);
            splitPane.setDividerLocation(420);
            splitPane.setResizeWeight(0.5);
            splitPane.setBorder(null);
            plotCards.setLayout(new BorderLayout());
            plotCards.add(splitPane, BorderLayout.CENTER);
            btn2DTab.setEnabled(false);
            btn3DTab.setEnabled(false);
        } else {
            isSplitPaneActive = false;
            plotCards.removeAll();
            plotCards.setLayout(plotCardLayout);
            plotCards.add(plot2D, "2D");
            plotCards.add(plot3D, "3D");
            plotCards.add(plot1D, "1D");
            if (loadedDimension == 1) {
                plotCardLayout.show(plotCards, "1D");
            } else if (is2DActive) {
                plotCardLayout.show(plotCards, "2D");
            } else {
                plotCardLayout.show(plotCards, "3D");
            }
            btn2DTab.setEnabled(true);
            btn3DTab.setEnabled(true);
        }
        plotCards.revalidate();
        plotCards.repaint();
    }
    
    // FID Generation
    private void generateMockFid() {
        Random rand = new Random(42);
        double w1 = 0.15;
        double w2 = 0.35;
        double decay1 = 0.01;
        double decay2 = 0.015;
        
        for (int t = 0; t < 500; t++) {
            double sigReal = 0.6 * Math.exp(-t * decay1) * Math.cos(w1 * t) +
                             0.4 * Math.exp(-t * decay2) * Math.cos(w2 * t);
            double sigImag = 0.6 * Math.exp(-t * decay1) * Math.sin(w1 * t) +
                             0.4 * Math.exp(-t * decay2) * Math.sin(w2 * t);
            
            sigReal += rand.nextGaussian() * 0.02;
            sigImag += rand.nextGaussian() * 0.02;
            
            fidReal[t] = sigReal;
            fidImag[t] = sigImag;
        }
        if (fidPlot != null) {
            fidPlot.setFidData(fidReal, fidImag, phc0_f2, phc1_f2);
        }
    }
    
    private void toggleFidVisibility() {
        isFidVisible = !isFidVisible;
        fidPlot.setVisible(isFidVisible);
        if (isFidVisible) {
            fidSplitPane.setDividerLocation(650);
        } else {
            fidSplitPane.setDividerLocation(900); // collapse
        }
        fidSplitPane.revalidate();
        fidSplitPane.repaint();
    }
    
    // Vertical Command Shortcut Button Creator
    private JButton createShortcutButton(String command, String tooltip, ActionListener action) {
        JButton btn = new JButton(command);
        btn.setToolTipText(tooltip);
        btn.setFont(new Font("Courier New", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(60, 70, 80));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_BLUE_BORDER),
            BorderFactory.createEmptyBorder(4, 4, 4, 4)
        ));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
        btn.setMaximumSize(new Dimension(48, 28));
        btn.setPreferredSize(new Dimension(48, 28));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setBackground(COLOR_PLOT_BLUE);
            }
            public void mouseExited(MouseEvent evt) {
                btn.setBackground(new Color(60, 70, 80));
            }
        });
        
        if (action != null) {
            btn.addActionListener(action);
        }
        return btn;
    }

    // Border Helper (2007 Light Theme Styled)
    public static Border createRetroBorder(String title) {
        return UIConstants.createRetroBorder(title);
    }
    
    // Button Helper (2007 Light Theme Styled)
    public static JButton createRetroButton(String label) {
        return UIConstants.createRetroButton(label);
    }
    
    private JComboBox<String> createRetroComboBox() {
        return UIConstants.createRetroComboBox();
    }


    public void autoLoadPath(String pathStr) {
        File file = new File(pathStr);
        if (!file.exists()) {
            log("ERROR: Startup path does not exist: " + pathStr);
            return;
        }
        String brukerRoot = getBrukerRootPath(file);
        if (brukerRoot != null) {
            log("Auto-loading Bruker NMR directory from startup args: " + brukerRoot);
            setStatus("Loading Bruker " + new File(brukerRoot).getName());
            currentFileType = "bruker";
            currentFileContent = brukerRoot;
            parseAndLoadData();
        } else {
            log("Auto-loading local file from startup args: " + file.getName());
            setStatus("Loading " + file.getName());
            try {
                byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
                currentFileContent = new String(bytes, StandardCharsets.UTF_8);
                String name = file.getName().toLowerCase();
                if (name.endsWith(".csv")) {
                    currentFileType = "csv";
                } else {
                    currentFileType = "str";
                }
                parseAndLoadData();
            } catch (Exception ex) {
                log("ERROR: Failed to read startup file: " + ex.getMessage());
                setStatus("Error loading file");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception ex) {}
            
            NmrVisualizer app = new NmrVisualizer();
            app.setVisible(true);
            
            // Auto-apply config if provided as second arg or if outputs/best_config.json exists
            String configPath = null;
            if (args.length > 1) {
                configPath = args[1];
            } else {
                File cf = new File("outputs/best_config.json");
                if (cf.exists()) configPath = cf.getAbsolutePath();
            }
            if (configPath != null) {
                try {
                    String cfg = new String(java.nio.file.Files.readAllBytes(new File(configPath).toPath()), StandardCharsets.UTF_8);
                    java.util.regex.Pattern p;
                    java.util.regex.Matcher m;
                    p = java.util.regex.Pattern.compile("\"phc0_f2\"\\s*:\\s*([-0-9\\.]+)");
                    m = p.matcher(cfg);
                    if (m.find()) app.phc0_f2 = Double.parseDouble(m.group(1));
                    p = java.util.regex.Pattern.compile("\"phc1_f2\"\\s*:\\s*([-0-9\\.]+)");
                    m = p.matcher(cfg);
                    if (m.find()) app.phc1_f2 = Double.parseDouble(m.group(1));
                    p = java.util.regex.Pattern.compile("\"baseline_order\"\\s*:\\s*([-0-9]+)");
                    m = p.matcher(cfg);
                    if (m.find()) app.baselineOrder = Integer.parseInt(m.group(1));
                    p = java.util.regex.Pattern.compile("\"contour_base\"\\s*:\\s*([-0-9\\.]+)");
                    m = p.matcher(cfg);
                    if (m.find()) {
                        double cb = Double.parseDouble(m.group(1));
                        // The GUI earlier used (5.0 / spectralScale) when sending contour_base; preserve visual scaling by adjusting spectralScale
                        app.spectralScale = 5.0 / Math.max(0.0001, cb);
                    }
                    app.log("Auto-applied config from " + configPath);
                } catch (Exception ex) {
                    app.log("Failed to auto-apply config: " + ex.getMessage());
                }
            }

            if (args.length > 0) {
                app.autoLoadPath(args[0]);
            }
        });
    }
}
