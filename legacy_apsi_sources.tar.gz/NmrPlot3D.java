import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.util.*;
import java.util.List;

public class NmrPlot3D extends JPanel {
    public static final int DRAG_MODE_ROTATE = 0;
    public static final int DRAG_MODE_PAN = 1;
    
    private List<DataPoint> points = new ArrayList<>();
    private List<ContourLine> contourLines = new ArrayList<>();
    private String xLabel = "X";
    private String yLabel = "Y";
    private String zLabel = "Z";
    private boolean invertX = true;
    private boolean invertY = true;
    private boolean invertZ = true;
    private boolean showGrid = true;
    private boolean showLabels = true;
    private double stretchZ = 1.0;
    
    // Navigation States
    private double zoom = 1.0;
    private double yaw = 0.78;   
    private double pitch = 0.52; 
    private double offsetX = 0.0;
    private double offsetY = 0.0;
    private Point dragStart = null;
    private int dragMode = DRAG_MODE_ROTATE;
    
    // Click selection in 3D
    private DataPoint clickedPoint = null;
    private Point clickedScreenPos = null;
    
    // Data Ranges
    private double minX, maxX, minY, maxY, minZ, maxZ;

    public NmrPlot3D() {
        setBackground(UIConstants.COLOR_WHITE);
        
        MouseAdapter mouseAdapter = new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                dragStart = e.getPoint();
            }
            public void mouseReleased(MouseEvent e) {
                dragStart = null;
            }
            public void mouseClicked(MouseEvent e) {
                checkClick(e.getPoint());
            }
            public void mouseDragged(MouseEvent e) {
                if (dragStart != null) {
                    // Clear selection when dragging to keep viewport clean
                    clickedPoint = null;
                    clickedScreenPos = null;
                    
                    int dx = e.getX() - dragStart.x;
                    int dy = e.getY() - dragStart.y;
                    
                    // Pan if shift, ctrl, option (alt) or middle/right click, OR if explicitly in PAN mode
                    if (dragMode == DRAG_MODE_PAN || 
                        SwingUtilities.isRightMouseButton(e) || 
                        e.isShiftDown() || 
                        e.isControlDown() || 
                        e.isAltDown()) {
                        // Pan: moves the screen center offset along the screen plane
                        offsetX += dx;
                        offsetY += dy;
                    } else {
                        // Rotate: Yaw is inverted so drag-left rotates box left
                        yaw -= dx * 0.01;
                        pitch += dy * 0.01;
                    }
                    
                    dragStart = e.getPoint();
                    repaint();
                }
            }
            public void mouseWheelMoved(MouseWheelEvent e) {
                if (points.isEmpty()) return;
                
                double rotation = e.getPreciseWheelRotation();
                
                // Zoom if Ctrl, Meta (Cmd), or Alt is held
                if (e.isControlDown() || e.isAltDown() || e.isMetaDown()) {
                    double scaleFactor = 1.0 - rotation * 0.03; // Gentle 3% zoom change
                    if (scaleFactor < 0.8) scaleFactor = 0.8;
                    if (scaleFactor > 1.2) scaleFactor = 1.2;
                    
                    zoom *= scaleFactor;
                    if (zoom < 0.1) zoom = 0.1;
                    if (zoom > 10.0) zoom = 10.0;
                } else {
                    // Pan: move the graph plane along the viewport/screen plane
                    double panSpeed = 12.0;
                    if (e.isShiftDown()) {
                        offsetX -= rotation * panSpeed;
                    } else {
                        offsetY -= rotation * panSpeed;
                    }
                }
                
                repaint();
            }
        };
        addMouseListener(mouseAdapter);
        addMouseMotionListener(mouseAdapter);
        addMouseWheelListener(mouseAdapter);
    }

    public void setDragMode(int mode) {
        this.dragMode = mode;
    }

    public void setData(List<DataPoint> pts, List<ContourLine> contours, String xl, String yl, String zl, boolean ix, boolean iy, boolean iz) {
        this.points = pts;
        this.contourLines = contours;
        this.xLabel = xl;
        this.yLabel = yl;
        this.zLabel = zl;
        this.invertX = ix;
        this.invertY = iy;
        this.invertZ = iz;
        
        calculateRanges();
        resetView();
    }
    
    private void calculateRanges() {
        if (points.isEmpty()) return;
        minX = Double.MAX_VALUE; maxX = -Double.MAX_VALUE;
        minY = Double.MAX_VALUE; maxY = -Double.MAX_VALUE;
        minZ = Double.MAX_VALUE; maxZ = -Double.MAX_VALUE;
        
        for (DataPoint p : points) {
            if (p.x < minX) minX = p.x;
            if (p.x > maxX) maxX = p.x;
            if (p.y < minY) minY = p.y;
            if (p.y > maxY) maxY = p.y;
            if (p.z != null) {
                if (p.z < minZ) minZ = p.z;
                if (p.z > maxZ) maxZ = p.z;
            }
        }
        
        for (ContourLine cl : contourLines) {
            if (cl.level < minZ) minZ = cl.level;
            if (cl.level > maxZ) maxZ = cl.level;
        }
        
        if (minZ == Double.MAX_VALUE) {
            minZ = -1.0;
            maxZ = 1.0;
        }
        
        double padX = (maxX - minX) * 0.1; if (padX == 0) padX = 1.0;
        minX -= padX; maxX += padX;
        double padY = (maxY - minY) * 0.1; if (padY == 0) padY = 1.0;
        minY -= padY; maxY += padY;
        double padZ = (maxZ - minZ) * 0.1; if (padZ == 0) padZ = 1.0;
        minZ -= padZ; maxZ += padZ;
    }
    
    public void resetView() {
        zoom = 1.0;
        yaw = 0.78;
        pitch = 0.52;
        offsetX = 0.0;
        offsetY = 0.0;
        stretchZ = 1.0;
        clickedPoint = null;
        clickedScreenPos = null;
        repaint();
    }
    
    public void setShowGrid(boolean show) { this.showGrid = show; repaint(); }
    public void setShowLabels(boolean show) { this.showLabels = show; repaint(); }
    public void zoomX(double scaleFactor) { zoom *= scaleFactor; repaint(); }
    public void zoomZ(double scaleFactor) { stretchZ *= scaleFactor; repaint(); }
    
    public void zoomIn() {
        zoom *= 1.15;
        if (zoom > 10.0) zoom = 10.0;
        repaint();
    }
    
    public void zoomOut() {
        zoom /= 1.15;
        if (zoom < 0.1) zoom = 0.1;
        repaint();
    }

    private void checkClick(Point mousePos) {
        if (points.isEmpty()) return;
        DataPoint closest = null;
        double minDist = 8.0; // Click sensitivity pixels
        Point closestPos = null;
        
        for (DataPoint p : points) {
            if (p.z == null) continue;
            
            // Map actual values to normalized coordinates [-1, 1]
            double nx = 2.0 * (p.x - minX) / (maxX - minX) - 1.0;
            double ny = 2.0 * (p.y - minY) / (maxY - minY) - 1.0;
            double nz = 2.0 * (p.z - minZ) / (maxZ - minZ) - 1.0;
            
            if (invertX) nx = -nx;
            if (invertY) ny = -ny;
            if (invertZ) nz = -nz;
            
            Point pp = project(nx, ny, nz);
            double dist = mousePos.distance(pp);
            if (dist < minDist) {
                minDist = dist;
                closest = p;
                closestPos = pp;
            }
        }
        
        clickedPoint = closest;
        clickedScreenPos = closestPos;
        repaint();
    }

    private Point project(double x, double y, double z) {
        double cosY = Math.cos(yaw);
        double sinY = Math.sin(yaw);
        double x1 = x * cosY - z * sinY;
        double z1 = x * sinY + z * cosY;
        
        double cosP = Math.cos(pitch);
        double sinP = Math.sin(pitch);
        double y2 = y * cosP - z1 * sinP;
        
        int cx = getWidth() / 2 + (int)offsetX;
        int cy = getHeight() / 2 + (int)offsetY;
        double size = Math.min(getWidth(), getHeight()) * 0.3 * zoom;
        
        int px = cx + (int)(x1 * size);
        int py = cy - (int)(y2 * size);
        return new Point(px, py);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        g2.setColor(UIConstants.COLOR_WHITE);
        g2.fillRect(0, 0, width, height);
        
        if (points.isEmpty()) {
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            g2.setFont(UIConstants.FONT_SANS);
            g2.drawString("NO DATA LOADED", width / 2 - 50, height / 2);
            return;
        }
        
        // Draw Box borders
        if (showGrid) {
            g2.setColor(new Color(180, 180, 180));
            double[][] cubeVertices = {
                {-1, -1, -1}, {1, -1, -1}, {1, 1, -1}, {-1, 1, -1},
                {-1, -1,  1}, {1, -1,  1}, {1, 1,  1}, {-1, 1,  1}
            };
            
            Point[] pv = new Point[8];
            for (int i = 0; i < 8; i++) {
                pv[i] = project(cubeVertices[i][0], cubeVertices[i][1], cubeVertices[i][2]);
            }
            
            g2.drawLine(pv[0].x, pv[0].y, pv[1].x, pv[1].y);
            g2.drawLine(pv[1].x, pv[1].y, pv[2].x, pv[2].y);
            g2.drawLine(pv[2].x, pv[2].y, pv[3].x, pv[3].y);
            g2.drawLine(pv[3].x, pv[3].y, pv[0].x, pv[0].y);
            
            g2.drawLine(pv[4].x, pv[4].y, pv[5].x, pv[5].y);
            g2.drawLine(pv[5].x, pv[5].y, pv[6].x, pv[6].y);
            g2.drawLine(pv[6].x, pv[6].y, pv[7].x, pv[7].y);
            g2.drawLine(pv[7].x, pv[7].y, pv[4].x, pv[4].y);
            
            g2.drawLine(pv[0].x, pv[0].y, pv[4].x, pv[4].y);
            g2.drawLine(pv[1].x, pv[1].y, pv[5].x, pv[5].y);
            g2.drawLine(pv[2].x, pv[2].y, pv[6].x, pv[6].y);
            g2.drawLine(pv[3].x, pv[3].y, pv[7].x, pv[7].y);
            
            // Axes Labels
            g2.setFont(UIConstants.FONT_SANS_BOLD);
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            
            Point pxLabel = project(1.2, -1, -1);
            Point pyLabel = project(-1, 1.2, -1);
            Point pzLabel = project(-1, -1, 1.2);
            
            g2.drawString(xLabel, pxLabel.x, pxLabel.y);
            g2.drawString(yLabel, pyLabel.x, pyLabel.y);
            g2.drawString(zLabel, pzLabel.x, pzLabel.y);
        }
        
        // Draw contour lines in 3D
        for (ContourLine cl : contourLines) {
            if (cl.isPositive) {
                g2.setColor(new Color(30, 96, 145, 80)); // Blue positive contours
            } else {
                g2.setColor(new Color(230, 57, 70, 70)); // Red negative contours
            }
            g2.setStroke(new BasicStroke(1.0f));
            
            for (List<Point2D.Double> segment : cl.segments) {
                if (segment.size() < 2) continue;
                
                int[] xPoints = new int[segment.size()];
                int[] yPoints = new int[segment.size()];
                int nPoints = 0;
                
                for (Point2D.Double pt : segment) {
                    double nx = 2.0 * (pt.x - minX) / (maxX - minX) - 1.0;
                    double ny = 2.0 * (pt.y - minY) / (maxY - minY) - 1.0;
                    double nz = 2.0 * (cl.level * stretchZ - minZ) / (maxZ - minZ) - 1.0;
                    
                    if (invertX) nx = -nx;
                    if (invertY) ny = -ny;
                    if (invertZ) nz = -nz;
                    
                    Point pp = project(nx, ny, nz);
                    xPoints[nPoints] = pp.x;
                    yPoints[nPoints] = pp.y;
                    nPoints++;
                }
                
                g2.drawPolyline(xPoints, yPoints, nPoints);
            }
        }

        // Render 3D points
        for (DataPoint p : points) {
            if (p.z == null) continue;
            
            double nx = 2.0 * (p.x - minX) / (maxX - minX) - 1.0;
            double ny = 2.0 * (p.y - minY) / (maxY - minY) - 1.0;
            double nz = 2.0 * (p.z * stretchZ - minZ) / (maxZ - minZ) - 1.0;
            
            if (invertX) nx = -nx;
            if (invertY) ny = -ny;
            if (invertZ) nz = -nz;
            
            Point pp = project(nx, ny, nz);
            
            g2.setColor(UIConstants.COLOR_PLOT_BLUE);
            g2.fillOval(pp.x - 3, pp.y - 3, 6, 6);
            g2.setColor(new Color(15, 50, 75));
            g2.drawOval(pp.x - 3, pp.y - 3, 6, 6);
            
            if (showLabels) {
                g2.setFont(new Font("Arial", Font.PLAIN, 9));
                g2.setColor(UIConstants.COLOR_CHARCOAL);
                g2.drawString(p.residue + " (" + String.format("%.2f", p.x) + ")", pp.x + 5, pp.y - 2);
            }
        }
        
        // Render clicked point highlight & classic yellow tooltip showing details
        if (clickedPoint != null && clickedScreenPos != null) {
            g2.setColor(UIConstants.COLOR_PLOT_HOVER); // red highlight
            g2.fillOval(clickedScreenPos.x - 4, clickedScreenPos.y - 4, 8, 8);
            g2.setColor(Color.BLACK);
            g2.drawOval(clickedScreenPos.x - 4, clickedScreenPos.y - 4, 8, 8);
            
            String text1 = "Residue: " + clickedPoint.seqId + " " + clickedPoint.residue;
            String text2 = NmrVisualizer.getAtomDisplayName(xLabel, clickedPoint.residue) + ": " + String.format("%.3f ppm", clickedPoint.x);
            String text3 = NmrVisualizer.getAtomDisplayName(yLabel, clickedPoint.residue) + ": " + String.format("%.3f ppm", clickedPoint.y);
            String text4 = NmrVisualizer.getAtomDisplayName(zLabel, clickedPoint.residue) + ": " + String.format("%.3f ppm", clickedPoint.z);
            
            int tx = clickedScreenPos.x + 10;
            int ty = clickedScreenPos.y - 80;
            
            // Classic Windows yellow tooltip
            g2.setColor(UIConstants.COLOR_TOOLTIP_BG);
            g2.fillRect(tx, ty, 220, 65);
            g2.setColor(new Color(100, 100, 100)); // gray tooltip border
            g2.drawRect(tx, ty, 220, 65);
            
            g2.setColor(UIConstants.COLOR_CHARCOAL);
            g2.setFont(UIConstants.FONT_SANS);
            g2.drawString(text1, tx + 8, ty + 15);
            g2.drawString(text2, tx + 8, ty + 30);
            g2.drawString(text3, tx + 8, ty + 45);
            g2.drawString(text4, tx + 8, ty + 60);
        }
        
        // User Controls HUD Overlay
        g2.setColor(new Color(120, 120, 120));
        g2.setFont(UIConstants.FONT_SANS);
        g2.drawString("Mouse Drag: " + (dragMode == DRAG_MODE_ROTATE ? "Rotate Viewport" : "Pan Viewport"), 15, 20);
        g2.drawString("Shift/Control + Drag (or Right-Click Drag): Pan Viewport", 15, 35);
        g2.drawString("2-Finger Swipe (Scroll Wheel): Pan Viewport", 15, 50);
        g2.drawString("Ctrl / Cmd + Scroll (or Pinch): Zoom In/Out", 15, 65);
        g2.drawString("Mouse Click: Select point to view elements & shifts", 15, 80);
    }
}
